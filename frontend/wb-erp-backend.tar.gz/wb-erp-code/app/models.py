"""
数据库模型
"""
from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, Text, ForeignKey, Enum as SQLEnum, JSON
from sqlalchemy.orm import relationship
from app.database import Base
from app.models.profit_models import (
    ShopCostConfig, ProductCostHistory, SalesReport,
    ReportProductDetail, ExchangeRateRecord, PaymentRecord, FixedCost
)
import enum


class UserRole(str, enum.Enum):
    ADMIN = "admin"      # 管理员
    FINANCE = "finance"  # 财务
    MANAGER = "manager"  # 经理
    STAFF = "staff"      # 员工


class User(Base):
    """用户表"""
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    email = Column(String(100), nullable=True)
    hashed_password = Column(String(255), nullable=False)
    role = Column(SQLEnum(UserRole), default=UserRole.STAFF)
    is_active = Column(Boolean, default=False)
    # 权限配置
    allowed_menus = Column(JSON, default=list)  # 可访问的菜单key列表
    allowed_owners = Column(JSON, default=list)  # 可查看的负责人列表
    created_at = Column(DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Shanghai")))
    updated_at = Column(DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Shanghai")), onupdate=lambda ctx: datetime.now(ZoneInfo("Asia/Shanghai")))
    
    # 关系
    product_permissions = relationship("ProductPermission", back_populates="user")


class Shop(Base):
    """店铺表"""
    __tablename__ = "shops"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    api_token = Column(String(500), nullable=False)
    currency = Column(String(10), default="RUB")  # RUB/CNY
    exchange_rate = Column(Float, default=12.5)  # 汇率 (CNY/RUB)
    sync_enabled = Column(Boolean, default=True)
    sync_interval_hours = Column(Integer, default=24)
    last_sync_at = Column(DateTime, nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Shanghai")))
    updated_at = Column(DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Shanghai")), onupdate=lambda ctx: datetime.now(ZoneInfo("Asia/Shanghai")))
    
    # 关系
    products = relationship("Product", back_populates="shop")
    orders = relationship("Order", back_populates="shop")


class Product(Base):
    """产品表"""
    __tablename__ = "products"
    
    id = Column(Integer, primary_key=True, index=True)
    nm_id = Column(String(50), unique=True, index=True, nullable=False)
    sku = Column(String(100), nullable=False)
    shop_id = Column(Integer, ForeignKey("shops.id"), nullable=False)
    
    name = Column(String(500))
    custom_name = Column(String(500), nullable=True)
    owner = Column(String(100), nullable=True)
    weight = Column(Float, nullable=True)
    length = Column(Float, nullable=True)
    width = Column(Float, nullable=True)
    height = Column(Float, nullable=True)
    
    created_at = Column(DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Shanghai")))
    updated_at = Column(DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Shanghai")), onupdate=lambda ctx: datetime.now(ZoneInfo("Asia/Shanghai")))
    
    # 关系
    shop = relationship("Shop", back_populates="products")
    inventory_records = relationship("InventoryRecord", back_populates="product")
    order_items = relationship("OrderItem", back_populates="product")
    permissions = relationship("ProductPermission", back_populates="product")


class ProductPermission(Base):
    """产品权限表"""
    __tablename__ = "product_permissions"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    created_at = Column(DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Shanghai")))
    
    user = relationship("User", back_populates="product_permissions")
    product = relationship("Product", back_populates="permissions")


class InventoryRecord(Base):
    """库存入库记录"""
    __tablename__ = "inventory_records"
    
    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    quantity = Column(Integer, nullable=False)
    remaining_quantity = Column(Integer, nullable=False)
    product_cost = Column(Float, nullable=False)
    logistics_cost = Column(Float, default=0)
    warehouse_type = Column(String(20), default="own")
    inbound_at = Column(DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Shanghai")))
    note = Column(Text, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Shanghai")))
    
    product = relationship("Product", back_populates="inventory_records")


class InventorySnapshot(Base):
    """库存快照"""
    __tablename__ = "inventory_snapshots"
    
    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    warehouse_id = Column(String(50), nullable=False)
    warehouse_name = Column(String(100))
    quantity = Column(Integer, default=0)
    snapshot_at = Column(DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Shanghai")))


class Order(Base):
    """订单表"""
    __tablename__ = "orders"
    
    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(String(100), unique=True, index=True, nullable=False)
    shop_id = Column(Integer, ForeignKey("shops.id"), nullable=False)
    
    status = Column(String(50), default="new")
    total_amount = Column(Float, default=0)
    commission = Column(Float, default=0)
    logistics_fee = Column(Float, default=0)
    
    product_cost = Column(Float, default=0)
    ad_cost = Column(Float, default=0)
    other_cost = Column(Float, default=0)
    profit = Column(Float, default=0)
    profit_rate = Column(Float, default=0)
    
    order_date = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Shanghai")))
    updated_at = Column(DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Shanghai")), onupdate=lambda ctx: datetime.now(ZoneInfo("Asia/Shanghai")))
    
    shop = relationship("Shop", back_populates="orders")
    items = relationship("OrderItem", back_populates="order")


class OrderItem(Base):
    """订单明细"""
    __tablename__ = "order_items"
    
    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(Integer, ForeignKey("orders.id"), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=True)
    
    nm_id = Column(String(50), nullable=False)
    sku = Column(String(100))
    quantity = Column(Integer, default=1)
    price = Column(Float, default=0)
    total_price = Column(Float, default=0)
    
    created_at = Column(DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Shanghai")))
    
    order = relationship("Order", back_populates="items")
    product = relationship("Product", back_populates="order_items")


class AdRecord(Base):
    """广告数据记录"""
    __tablename__ = "ad_records"
    
    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    shop_id = Column(Integer, ForeignKey("shops.id"), nullable=False)
    
    ad_type = Column(String(50), default="search")
    advert_id = Column(Integer, default=0)
    
    impressions = Column(Integer, default=0)
    clicks = Column(Integer, default=0)
    cost = Column(Float, default=0)  # 花费（店铺货币）
    cost_cny = Column(Float, default=0)  # 花费（人民币）
    orders = Column(Integer, default=0)
    sales = Column(Float, default=0)  # 销售额（店铺货币）
    sales_cny = Column(Float, default=0)  # 销售额（人民币）
    
    cpm = Column(Float, default=0)
    cpc = Column(Float, default=0)
    
    ctr = Column(Float, default=0)
    conversion_rate = Column(Float, default=0)
    acos = Column(Float, default=0)
    roas = Column(Float, default=0)
    
    cart_count = Column(Integer, default=0)  # 加购数
    
    record_date = Column(DateTime, nullable=False)
    created_at = Column(DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Shanghai")))


class SystemSetting(Base):
    """系统设置"""
    __tablename__ = "system_settings"
    
    id = Column(Integer, primary_key=True, index=True)
    key = Column(String(100), unique=True, nullable=False)
    value = Column(Text, nullable=False)
    description = Column(String(500))
    updated_at = Column(DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Shanghai")), onupdate=lambda ctx: datetime.now(ZoneInfo("Asia/Shanghai")))


class UISetting(Base):
    """界面设置"""
    __tablename__ = "ui_settings"
    
    id = Column(Integer, primary_key=True, index=True)
    login_logo = Column(String(200), default="🌿")
    login_title = Column(String(100), default="WB ERP")
    login_subtitle = Column(String(200), default="Wildberries 跨境电商管理系统")
    sidebar_logo = Column(String(200), default="🍀 WB ERP")
    primary_color = Column(String(20), default="#8b5cf6")
    footer_text = Column(String(200), default="")
    updated_at = Column(DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Shanghai")), onupdate=lambda ctx: datetime.now(ZoneInfo("Asia/Shanghai")))


class MenuItem(Base):
    """菜单项配置"""
    __tablename__ = "menu_items"
    
    id = Column(Integer, primary_key=True, index=True)
    key = Column(String(50), unique=True, nullable=False)
    name = Column(String(50), nullable=False)
    icon = Column(String(50), nullable=True)
    path = Column(String(100), nullable=False)
    parent_key = Column(String(50), nullable=True)
    sort_order = Column(Integer, default=0)
    is_visible = Column(Boolean, default=True)
    required_role = Column(String(20), nullable=True)  # admin/finance/manager/staff
    created_at = Column(DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Shanghai")))
    updated_at = Column(DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Shanghai")), onupdate=lambda ctx: datetime.now(ZoneInfo("Asia/Shanghai")))


class SyncLog(Base):
    """同步日志"""
    __tablename__ = "sync_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    shop_id = Column(Integer, ForeignKey("shops.id"), nullable=False)
    sync_type = Column(String(50), nullable=False)
    status = Column(String(20), default="running")
    message = Column(Text, nullable=True)
    records_count = Column(Integer, default=0)
    started_at = Column(DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Shanghai")))
    finished_at = Column(DateTime, nullable=True)

# 动态添加利润核算关系
Shop.cost_config = relationship("ShopCostConfig", back_populates="shop", uselist=False)
Shop.sales_reports = relationship("SalesReport", back_populates="shop")
Product.cost_histories = relationship("ProductCostHistory", back_populates="product")
