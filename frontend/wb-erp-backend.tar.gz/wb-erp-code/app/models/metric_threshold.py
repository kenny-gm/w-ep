"""
指标阈值设置模型
"""
from sqlalchemy import Column, Integer, Float, String, DateTime, Boolean
from sqlalchemy.sql import func
from app.database import Base


class MetricThreshold(Base):
    """指标阈值配置表"""
    __tablename__ = "metric_thresholds"
    
    id = Column(Integer, primary_key=True, index=True)
    
    # 指标名称
    metric_name = Column(String(50), unique=True, nullable=False)  # roas, acos, ctr, natural_orders_ratio
    
    # 阈值配置
    warning_threshold = Column(Float, nullable=False)  # 警告阈值
    danger_threshold = Column(Float, nullable=True)    # 危险阈值
    
    # 比较方式: less_than, greater_than
    comparison = Column(String(20), default="less_than")
    
    # 颜色配置
    good_color = Column(String(20), default="#67c23a")     # 绿色
    warning_color = Column(String(20), default="#e6a23c")  # 黄色
    danger_color = Column(String(20), default="#f56c6c")   # 红色
    
    # 显示名称
    display_name = Column(String(50), nullable=False)
    
    # 是否启用
    is_active = Column(Boolean, default=True)
    
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())
