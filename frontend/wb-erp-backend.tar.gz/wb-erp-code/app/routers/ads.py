"""
广告分析路由
"""
from datetime import datetime, timedelta
from typing import Optional
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.database import get_db
from app.models.models import AdRecord, Product
from app.routers.auth import get_current_user

router = APIRouter(prefix="/ads", tags=["广告分析"])


@router.get("/")
def list_ads(
    skip: int = 0,
    limit: int = 20,
    shop_id: Optional[int] = None,
    ad_type: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """获取广告数据列表"""
    query = db.query(AdRecord)
    
    if shop_id:
        query = query.filter(AdRecord.shop_id == shop_id)
    
    if ad_type:
        query = query.filter(AdRecord.ad_type == ad_type)
    
    if start_date:
        query = query.filter(AdRecord.record_date >= datetime.strptime(start_date, "%Y-%m-%d"))
    
    if end_date:
        query = query.filter(AdRecord.record_date <= datetime.strptime(end_date, "%Y-%m-%d"))
    
    total = query.count()
    records = query.order_by(AdRecord.record_date.desc()).offset(skip).limit(limit).all()
    
    # 关联产品信息
    items = []
    for r in records:
        product = db.query(Product).filter(Product.id == r.product_id).first()
        items.append({
            **r.__dict__,
            "product": {
                "id": product.id,
                "nm_id": product.nm_id,
                "name": product.name,
                "custom_name": product.custom_name
            } if product else None
        })
    
    return {"items": items, "total": total}


@router.get("/summary/")
def ad_summary(
    shop_id: Optional[int] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """广告数据汇总"""
    query = db.query(AdRecord)
    
    if shop_id:
        query = query.filter(AdRecord.shop_id == shop_id)
    
    if start_date:
        query = query.filter(AdRecord.record_date >= datetime.strptime(start_date, "%Y-%m-%d"))
    
    if end_date:
        query = query.filter(AdRecord.record_date <= datetime.strptime(end_date, "%Y-%m-%d"))
    
    records = query.all()
    
    return {
        "total_impressions": sum(r.impressions for r in records),
        "total_clicks": sum(r.clicks for r in records),
        "total_cost": sum(r.cost for r in records),
        "total_sales": sum(r.sales for r in records),
        "total_orders": sum(r.orders for r in records),
        "avg_ctr": sum(r.ctr for r in records) / len(records) if records else 0,
        "avg_cpc": sum(r.cpc for r in records) / len(records) if records else 0,
        "avg_cpm": sum(r.cpm for r in records) / len(records) if records else 0,
        "avg_acos": sum(r.acos for r in records) / len(records) if records else 0,
        "avg_roas": sum(r.roas for r in records) / len(records) if records else 0
    }


@router.get("/by-product/")
def ads_by_product(
    shop_id: Optional[int] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """按产品汇总广告数据"""
    query = db.query(
        AdRecord.product_id,
        func.sum(AdRecord.impressions).label("impressions"),
        func.sum(AdRecord.clicks).label("clicks"),
        func.sum(AdRecord.cost).label("cost"),
        func.sum(AdRecord.sales).label("sales"),
        func.sum(AdRecord.orders).label("orders"),
        func.avg(AdRecord.ctr).label("avg_ctr"),
        func.avg(AdRecord.cpc).label("avg_cpc"),
        func.avg(AdRecord.cpm).label("avg_cpm"),
        func.avg(AdRecord.acos).label("avg_acos"),
        func.avg(AdRecord.roas).label("avg_roas")
    )
    
    if shop_id:
        query = query.filter(AdRecord.shop_id == shop_id)
    
    if start_date:
        query = query.filter(AdRecord.record_date >= datetime.strptime(start_date, "%Y-%m-%d"))
    
    if end_date:
        query = query.filter(AdRecord.record_date <= datetime.strptime(end_date, "%Y-%m-%d"))
    
    results = query.group_by(AdRecord.product_id).all()
    
    items = []
    for r in results:
        product = db.query(Product).filter(Product.id == r.product_id).first()
        items.append({
            "product_id": r.product_id,
            "product": {
                "nm_id": product.nm_id,
                "name": product.name,
                "custom_name": product.custom_name
            } if product else None,
            "impressions": r.impressions,
            "clicks": r.clicks,
            "cost": r.cost,
            "sales": r.sales,
            "orders": r.orders,
            "avg_ctr": r.avg_ctr,
            "avg_cpc": r.avg_cpc,
            "avg_cpm": r.avg_cpm,
            "avg_acos": r.avg_acos,
            "avg_roas": r.avg_roas
        })
    
    return items
