"""
销售看板路由
"""
from datetime import datetime, timedelta
from typing import Optional, List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel

from app.database import get_db
from app.models.models import Shop, Product, Order, AdRecord
from app.routers.auth import get_current_user

router = APIRouter(prefix="/dashboard", tags=["销售看板"])


class DashboardFilter(BaseModel):
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    shop_ids: Optional[List[int]] = None
    owners: Optional[List[str]] = None
    product_ids: Optional[List[int]] = None


class DashboardStats(BaseModel):
    sales_amount: float = 0
    order_count: int = 0
    visitors: int = 0
    add_to_cart: int = 0
    add_to_cart_rate: float = 0
    conversion_rate: float = 0
    ad_cost: float = 0
    ad_ratio: float = 0
    ad_ratio_alert: str = "normal"
    currency: str = "RUB"
    comparison: Optional[dict] = None


def get_shop_exchange_rates(db: Session) -> dict:
    """获取所有店铺的汇率配置"""
    shops = db.query(Shop).filter(Shop.is_active == True).all()
    return {shop.id: {"currency": shop.currency or "RUB", "rate": shop.exchange_rate or 12.5} for shop in shops}


def convert_currency(amount: float, to_currency: str, exchange_rate: float) -> float:
    """
    转换金额为卢布显示
    - 存储的是原始金额，根据店铺货币类型进行转换
    - 如果店铺货币是CNY，将人民币转换为卢布（乘以汇率）
    - 如果店铺货币是RUB，直接返回卢布
    """
    if not amount:
        return 0
    
    # 根据店铺货币类型进行转换
    if to_currency == "CNY":
        # 店铺是CNY，存储的是人民币，需要转换为卢布显示（乘以汇率）
        return amount * exchange_rate if exchange_rate else amount
    else:
        # 店铺是RUB，直接返回卢布
        return amount


@router.post("/stats/", response_model=DashboardStats)
def get_dashboard_stats(
    filter_data: DashboardFilter,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """获取销售看板数据"""
    # 默认显示昨天
    yesterday = datetime.now() - timedelta(days=1)
    
    if filter_data.start_date:
        start_date = datetime.strptime(filter_data.start_date, "%Y-%m-%d")
    else:
        start_date = yesterday
    
    if filter_data.end_date:
        end_date = datetime.strptime(filter_data.end_date, "%Y-%m-%d") + timedelta(days=1)
    else:
        end_date = start_date + timedelta(days=1)
    
    # 计算上一周期（同比）
    period_days = (end_date - start_date).days
    prev_start = start_date - timedelta(days=period_days)
    prev_end = start_date
    
    shop_rates = get_shop_exchange_rates(db)
    
    # 判断筛选条件
    has_shop_filter = filter_data.shop_ids and len(filter_data.shop_ids) > 0
    has_owner_filter = filter_data.owners and len(filter_data.owners) > 0
    
    # 获取汇率配置 - 根据筛选条件决定
    if has_shop_filter and len(filter_data.shop_ids) == 1:
        shop_config = shop_rates.get(filter_data.shop_ids[0], {"currency": "RUB", "rate": 12.5})
    else:
        shop_config = {"currency": "RUB", "rate": 12.5}
    
    stats = DashboardStats(currency=shop_config["currency"])
    
    # ==================== 根据筛选条件处理 ====================
    if has_owner_filter:
        # 场景：有负责人筛选
        from app.models.models import Product
        
        # 查询指定负责人对应的产品ID
        products_query = db.query(Product.id).filter(
            Product.owner.in_(filter_data.owners)
        )
        if has_shop_filter:
            products_query = products_query.filter(Product.shop_id.in_(filter_data.shop_ids))
        product_ids = [p[0] for p in products_query.all()]
        
        if not product_ids:
            return stats
        
        # 从product_analytics表汇总（销售额、访客、加购、订单）
        ads_query = db.query(AdRecord).filter(
            AdRecord.record_date >= start_date.strftime("%Y-%m-%d"),
            AdRecord.record_date < end_date.strftime("%Y-%m-%d"),
            AdRecord.ad_type == "product_analytics",
            AdRecord.product_id.in_(product_ids)
        )
        if has_shop_filter:
            ads_query = ads_query.filter(AdRecord.shop_id.in_(filter_data.shop_ids))
        
        ads = ads_query.all()
        
        # 从advertising表查询广告费用
        ads_cost_query = db.query(AdRecord).filter(
            AdRecord.record_date >= start_date.strftime("%Y-%m-%d"),
            AdRecord.record_date < end_date.strftime("%Y-%m-%d"),
            AdRecord.ad_type == "advertising",
            AdRecord.product_id.in_(product_ids)
        )
        if has_shop_filter:
            ads_cost_query = ads_cost_query.filter(AdRecord.shop_id.in_(filter_data.shop_ids))
        
        ads_costs = ads_cost_query.all()
        
        for ad in ads:
            sales_val = convert_currency(ad.sales or 0, shop_config["currency"], shop_config["rate"])
            stats.sales_amount += sales_val
            stats.visitors += ad.impressions or 0
            stats.add_to_cart += ad.clicks or 0
            stats.order_count += ad.orders or 0
        
        # 广告费用
        for ad in ads_costs:
            stats.ad_cost += ad.cost or 0
    else:
        # 场景：无负责人筛选
        # 从analytics表获取店铺级别汇总
        ads_query = db.query(AdRecord).filter(
            AdRecord.record_date >= start_date.strftime("%Y-%m-%d"),
            AdRecord.record_date < end_date.strftime("%Y-%m-%d"),
            AdRecord.ad_type == "analytics",
            AdRecord.product_id == 0
        )
        if has_shop_filter:
            ads_query = ads_query.filter(AdRecord.shop_id.in_(filter_data.shop_ids))
        
        ads = ads_query.all()
        
        # 查询广告费用数据
        ads_cost_query = db.query(AdRecord).filter(
            AdRecord.record_date >= start_date.strftime("%Y-%m-%d"),
            AdRecord.record_date < end_date.strftime("%Y-%m-%d"),
            AdRecord.ad_type == "advertising"
        )
        if has_shop_filter:
            ads_cost_query = ads_cost_query.filter(AdRecord.shop_id.in_(filter_data.shop_ids))
        
        ads_costs = ads_cost_query.all()
        
        # 从orders表获取销售额（只按店铺筛选）
        orders_query = db.query(Order).filter(
            Order.order_date >= start_date.strftime("%Y-%m-%d"),
            Order.order_date < end_date.strftime("%Y-%m-%d")
        )
        if has_shop_filter:
            orders_query = orders_query.filter(Order.shop_id.in_(filter_data.shop_ids))
        orders = orders_query.all()
        
        for order in orders:
            order_shop_config = shop_rates.get(order.shop_id, {"currency": "RUB", "rate": 12.5})
            sales_val = convert_currency(order.total_amount, order_shop_config["currency"], order_shop_config["rate"])
            stats.sales_amount += sales_val
        
        for ad in ads:
            stats.visitors += ad.impressions or 0
            stats.add_to_cart += ad.clicks or 0
            stats.order_count += ad.orders or 0
        
        # 从广告表获取广告费用
        for ad in ads_costs:
            stats.ad_cost += ad.cost or 0
    
    # 计算转化率等指标
    if stats.visitors > 0:
        stats.add_to_cart_rate = stats.add_to_cart / stats.visitors * 100
    
    if stats.sales_amount > 0:
        stats.ad_ratio = stats.ad_cost / stats.sales_amount
    
    if stats.ad_ratio >= 0.05:
        stats.ad_ratio_alert = "danger"
    elif stats.ad_ratio >= 0.03:
        stats.ad_ratio_alert = "warning"
    
    # 设置货币类型
    stats.currency = shop_config["currency"]
    
    # 计算转化率
    if stats.visitors > 0:
        stats.conversion_rate = stats.order_count / stats.visitors * 100
    
    # ===== 计算上一周期数据 =====
    if has_owner_filter:
        # 上一周期也按负责人筛选
        from app.models.models import Product
        
        products_query = db.query(Product.id).filter(
            Product.owner.in_(filter_data.owners)
        )
        if has_shop_filter:
            products_query = products_query.filter(Product.shop_id.in_(filter_data.shop_ids))
        prev_product_ids = [p[0] for p in products_query.all()]
        
        if prev_product_ids:
            prev_ads_query = db.query(AdRecord).filter(
                AdRecord.record_date >= prev_start.strftime("%Y-%m-%d"),
                AdRecord.record_date < prev_end,
                AdRecord.ad_type == "product_analytics",
                AdRecord.product_id.in_(prev_product_ids)
            )
            if has_shop_filter:
                prev_ads_query = prev_ads_query.filter(AdRecord.shop_id.in_(filter_data.shop_ids))
            
            prev_ads = prev_ads_query.all()
            prev_stats = {"sales_amount": 0, "order_count": 0, "visitors": 0, "add_to_cart": 0, "ad_cost": 0}
            for ad in prev_ads:
                prev_stats["sales_amount"] += convert_currency(ad.sales or 0, shop_config["currency"], shop_config["rate"])
                prev_stats["visitors"] += ad.impressions or 0
                prev_stats["add_to_cart"] += ad.clicks or 0
                prev_stats["order_count"] += ad.orders or 0
        else:
            prev_stats = {"sales_amount": 0, "order_count": 0, "visitors": 0, "add_to_cart": 0, "ad_cost": 0}
    else:
        # 上一周期无负责人筛选
        prev_ads_query = db.query(AdRecord).filter(
            AdRecord.record_date >= prev_start.strftime("%Y-%m-%d"),
            AdRecord.record_date < prev_end,
            AdRecord.ad_type == "analytics",
            AdRecord.product_id == 0
        )
        if has_shop_filter:
            prev_ads_query = prev_ads_query.filter(AdRecord.shop_id.in_(filter_data.shop_ids))
        
        prev_ads = prev_ads_query.all()
        prev_stats = {"sales_amount": 0, "order_count": 0, "visitors": 0, "add_to_cart": 0, "ad_cost": 0}
        
        # 从orders表获取上一周期销售额
        prev_orders_query = db.query(Order).filter(
            Order.order_date >= prev_start,
            Order.order_date < prev_end
        )
        if has_shop_filter:
            prev_orders_query = prev_orders_query.filter(Order.shop_id.in_(filter_data.shop_ids))
        prev_orders = prev_orders_query.all()
        
        for order in prev_orders:
            order_shop_config = shop_rates.get(order.shop_id, {"currency": "RUB", "rate": 12.5})
            prev_stats["sales_amount"] += convert_currency(order.total_amount, order_shop_config["currency"], order_shop_config["rate"])
        
        for ad in prev_ads:
            prev_stats["visitors"] += ad.impressions or 0
            prev_stats["add_to_cart"] += ad.clicks or 0
            prev_stats["order_count"] += ad.orders or 0
        
        # 从advertising表获取上一周期广告费用
        prev_ads_cost_query = db.query(AdRecord).filter(
            AdRecord.record_date >= prev_start.strftime("%Y-%m-%d"),
            AdRecord.record_date < prev_end,
            AdRecord.ad_type == "advertising"
        )
        if has_shop_filter:
            prev_ads_cost_query = prev_ads_cost_query.filter(AdRecord.shop_id.in_(filter_data.shop_ids))
        
        prev_ads_costs = prev_ads_cost_query.all()
        for ad in prev_ads_costs:
            prev_stats["ad_cost"] += ad.cost or 0
    
    # 计算同比百分比
    def calc_percent(current, previous):
        if previous == 0:
            return None if current == 0 else 100.0
        return (current - previous) / previous * 100
    
    stats.comparison = {
        "sales_amount": calc_percent(stats.sales_amount, prev_stats["sales_amount"]),
        "order_count": calc_percent(stats.order_count, prev_stats["order_count"]),
        "visitors": calc_percent(stats.visitors, prev_stats["visitors"]),
        "add_to_cart": calc_percent(stats.add_to_cart, prev_stats["add_to_cart"]),
        "add_to_cart_rate": calc_percent(
            stats.add_to_cart_rate, 
            prev_stats["visitors"] > 0 and (prev_stats["add_to_cart"] / prev_stats["visitors"] * 100) or 0
        ),
        "conversion_rate": calc_percent(
            stats.conversion_rate,
            prev_stats["visitors"] > 0 and (prev_stats["order_count"] / prev_stats["visitors"] * 100) or 0
        ),
        "ad_cost": calc_percent(stats.ad_cost, prev_stats["ad_cost"]),
        "ad_ratio": calc_percent(
            stats.ad_ratio * 100,
            prev_stats["sales_amount"] > 0 and (prev_stats["ad_cost"] / prev_stats["sales_amount"] * 100) or 0
        )
    }
    
    return stats


@router.post("/trend/")
def get_sales_trend(
    filter_data: DashboardFilter,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """获取销售趋势 - 显示销售额、订单数、广告费"""
    if filter_data.start_date:
        start_date = datetime.strptime(filter_data.start_date, "%Y-%m-%d")
    else:
        start_date = datetime.now() - timedelta(days=30)
    
    if filter_data.end_date:
        end_date = datetime.strptime(filter_data.end_date, "%Y-%m-%d") + timedelta(days=1)
    else:
        end_date = datetime.now() + timedelta(days=1)
    
    shop_rates = get_shop_exchange_rates(db)
    
    # 查询订单汇总数据
    query = db.query(Order).filter(
        Order.order_date >= start_date.strftime("%Y-%m-%d"),
        Order.order_date < end_date.strftime("%Y-%m-%d")
    )
    if filter_data.shop_ids:
        query = query.filter(Order.shop_id.in_(filter_data.shop_ids))
    
    orders = query.all()
    
    # 查询广告费用数据（所有产品的广告费用汇总）
    ads_cost_query = db.query(AdRecord).filter(
        AdRecord.record_date >= start_date.strftime("%Y-%m-%d"),
        AdRecord.record_date < end_date.strftime("%Y-%m-%d"),
        AdRecord.ad_type == "advertising"  # 只查询广告费用数据
    )
    if filter_data.shop_ids:
        ads_cost_query = ads_cost_query.filter(AdRecord.shop_id.in_(filter_data.shop_ids))
    
    ads_costs = ads_cost_query.all()
    
    # 查询访客/加购数据（店铺级别汇总）
    ads_query = db.query(AdRecord).filter(
        AdRecord.record_date >= start_date.strftime("%Y-%m-%d"),
        AdRecord.record_date < end_date.strftime("%Y-%m-%d"),
        AdRecord.ad_type == "analytics",
        AdRecord.product_id == 0
    )
    if filter_data.shop_ids:
        ads_query = ads_query.filter(AdRecord.shop_id.in_(filter_data.shop_ids))
    
    ads = ads_query.all()
    
    # 按日期汇总
    daily_data = {}
    for order in orders:
        date_str = order.order_date.strftime("%Y-%m-%d") if order.order_date else "unknown"
        if date_str not in daily_data:
            daily_data[date_str] = {"sales": 0, "orders": 0, "ad_cost": 0}
        
        shop_config = shop_rates.get(order.shop_id, {"currency": "RUB", "rate": 12.5})
        daily_data[date_str]["sales"] += convert_currency(order.total_amount, shop_config["currency"], shop_config["rate"])
    
    # 从analytics数据获取订单数
    for ad in ads:
        date_str = ad.record_date.strftime("%Y-%m-%d") if ad.record_date else "unknown"
        if date_str not in daily_data:
            daily_data[date_str] = {"sales": 0, "orders": 0, "ad_cost": 0}
        daily_data[date_str]["orders"] += ad.orders or 0
    
    # 从广告数据获取广告费用
    for ad in ads_costs:
        date_str = ad.record_date.strftime("%Y-%m-%d") if ad.record_date else "unknown"
        if date_str not in daily_data:
            daily_data[date_str] = {"sales": 0, "orders": 0, "ad_cost": 0}
        daily_data[date_str]["ad_cost"] += ad.cost or 0
    
    return [{"date": d, **data} for d, data in sorted(daily_data.items())]


@router.get("/owners/")
def get_owners(
    shop_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """获取所有产品负责人 - 支持按店铺筛选"""
    query = db.query(Product.owner).filter(Product.owner != None, Product.owner != "")
    if shop_id:
        query = query.filter(Product.shop_id == shop_id)
    owners = query.distinct().all()
    return [o[0] for o in owners if o[0]]


class ComparisonData(BaseModel):
    sales_amount: Optional[float] = None
    order_count: Optional[float] = None
    visitors: Optional[float] = None
    add_to_cart: Optional[float] = None
    add_to_cart_rate: Optional[float] = None
    conversion_rate: Optional[float] = None
    ad_cost: Optional[float] = None
    ad_ratio: Optional[float] = None


def get_stats_for_period(db: Session, start_date: datetime, end_date: datetime, shop_ids: List[int] = None) -> dict:
    """获取指定时间段的统计数据"""
    shop_rates = get_shop_exchange_rates(db)
    
    query = db.query(Order).filter(
        Order.order_date >= start_date.strftime("%Y-%m-%d"),
        Order.order_date <= end_date
    )
    
    if shop_ids:
        query = query.filter(Order.shop_id.in_(shop_ids))
    
    orders = query.all()
    
    stats = {
        "sales_amount": 0,
        "order_count": 0,
        "ad_cost": 0
    }
    
    for order in orders:
        shop_config = shop_rates.get(order.shop_id, {"currency": "RUB", "rate": 12.5})
        stats["sales_amount"] += convert_currency(order.total_amount, shop_config["currency"], shop_config["rate"])
        stats["ad_cost"] += convert_currency(order.ad_cost, shop_config["currency"], shop_config["rate"])
        stats["order_count"] += 1
    
    # 广告数据 - 访客和加购（从analytics表）
    ads_query = db.query(AdRecord).filter(
        AdRecord.record_date >= start_date.strftime("%Y-%m-%d"),
        AdRecord.record_date <= end_date,
        AdRecord.ad_type == "analytics",
        AdRecord.product_id == 0
    )
    if shop_ids:
        ads_query = ads_query.filter(AdRecord.shop_id.in_(shop_ids))
    
    ads = ads_query.all()
    stats["visitors"] = sum(ad.impressions or 0 for ad in ads)
    stats["add_to_cart"] = sum(ad.clicks or 0 for ad in ads)
    
    # 广告费用（从advertising表）
    ads_cost_query = db.query(AdRecord).filter(
        AdRecord.record_date >= start_date.strftime("%Y-%m-%d"),
        AdRecord.record_date <= end_date,
        AdRecord.ad_type == "advertising"
    )
    if shop_ids:
        ads_cost_query = ads_cost_query.filter(AdRecord.shop_id.in_(shop_ids))
    
    ads_costs = ads_cost_query.all()
    stats["ad_cost"] = sum(ad.cost or 0 for ad in ads_costs)
    
    if stats["visitors"] > 0:
        stats["add_to_cart_rate"] = stats["add_to_cart"] / stats["visitors"] * 100
        stats["conversion_rate"] = stats["order_count"] / stats["visitors"] * 100
    
    if stats["sales_amount"] > 0:
        stats["ad_ratio"] = stats["ad_cost"] / stats["sales_amount"]
    
    return stats


def calculate_change(current: float, previous: float) -> float:
    """计算变化百分比"""
    if not previous or previous == 0:
        return None
    return ((current - previous) / previous) * 100


@router.post("/comparison/", response_model=ComparisonData)
def get_comparison(
    filter_data: DashboardFilter,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """获取环比数据（与上一个时间段对比）"""
    if not filter_data.start_date or not filter_data.end_date:
        return ComparisonData()
    
    start_date = datetime.strptime(filter_data.start_date, "%Y-%m-%d")
    end_date = datetime.strptime(filter_data.end_date, "%Y-%m-%d")
    
    period_days = (end_date - start_date).days + 1
    
    # 上一周期
    prev_start = start_date - timedelta(days=period_days)
    prev_end = start_date - timedelta(days=1)
    
    current_stats = get_stats_for_period(db, start_date, end_date + timedelta(days=1), filter_data.shop_ids)
    prev_stats = get_stats_for_period(db, prev_start, prev_end + timedelta(days=1), filter_data.shop_ids)
    
    return ComparisonData(
        sales_amount=calculate_change(current_stats.get("sales_amount", 0), prev_stats.get("sales_amount", 0)),
        order_count=calculate_change(current_stats.get("order_count", 0), prev_stats.get("order_count", 0)),
        visitors=calculate_change(current_stats.get("visitors", 0), prev_stats.get("visitors", 0)),
        add_to_cart=calculate_change(current_stats.get("add_to_cart", 0), prev_stats.get("add_to_cart", 0)),
        add_to_cart_rate=calculate_change(current_stats.get("add_to_cart_rate", 0), prev_stats.get("add_to_cart_rate", 0)),
        conversion_rate=calculate_change(current_stats.get("conversion_rate", 0), prev_stats.get("conversion_rate", 0)),
        ad_cost=calculate_change(current_stats.get("ad_cost", 0), prev_stats.get("ad_cost", 0)),
        ad_ratio=calculate_change(current_stats.get("ad_ratio", 0), prev_stats.get("ad_ratio", 0))
    )


@router.post("/by-owner/")
def get_stats_by_owner(
    filter_data: DashboardFilter,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """按负责人统计销售数据"""
    if filter_data.start_date:
        start_date = datetime.strptime(filter_data.start_date, "%Y-%m-%d")
    else:
        start_date = datetime.now() - timedelta(days=7)
    
    if filter_data.end_date:
        end_date = datetime.strptime(filter_data.end_date, "%Y-%m-%d") + timedelta(days=1)
    else:
        end_date = datetime.now() + timedelta(days=1)
    
    shop_rates = get_shop_exchange_rates(db)
    
    # 获取产品-负责人映射
    products = db.query(Product).filter(Product.owner != None, Product.owner != "")
    if filter_data.shop_ids:
        products = products.filter(Product.shop_id.in_(filter_data.shop_ids))
    if filter_data.owners:
        products = products.filter(Product.owner.in_(filter_data.owners))
    
    products = products.all()
    
    # 按负责人汇总
    owner_stats = {}
    for product in products:
        owner = product.owner
        if not owner:
            continue
        
        if owner not in owner_stats:
            owner_stats[owner] = {
                "owner": owner,
                "sales": 0,
                "orders": 0,
                "visitors": 0,
                "add_to_cart": 0,
                "ad_cost": 0
            }
        
        # 从ad_records获取该产品的数据
        ad_records = db.query(AdRecord).filter(
            AdRecord.product_id == product.id,
            AdRecord.record_date >= start_date.strftime("%Y-%m-%d"),
            AdRecord.record_date < end_date.strftime("%Y-%m-%d")
        ).all()
        
        for ad in ad_records:
            shop_config = shop_rates.get(product.shop_id, {"currency": "RUB", "rate": 12.5})
            owner_stats[owner]["sales"] += convert_currency(ad.sales or 0, shop_config["currency"], shop_config["rate"])
            owner_stats[owner]["orders"] += ad.orders or 0
            owner_stats[owner]["visitors"] += ad.impressions or 0
            owner_stats[owner]["add_to_cart"] += ad.clicks or 0
            owner_stats[owner]["ad_cost"] += ad.cost or 0
    
    return list(owner_stats.values())
