"""
财务分析路由
"""
from datetime import datetime, timedelta
from typing import Optional
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.database import get_db
from app.models.models import Order, OrderItem, AdRecord, Product
from app.routers.auth import get_current_user

router = APIRouter(prefix="/finance", tags=["财务分析"])


@router.get("/summary/")
def finance_summary(
    shop_id: Optional[int] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """财务汇总"""
    query = db.query(Order)
    
    if shop_id:
        query = query.filter(Order.shop_id == shop_id)
    
    if start_date:
        query = query.filter(Order.order_date >= datetime.strptime(start_date, "%Y-%m-%d"))
    
    if end_date:
        query = query.filter(Order.order_date <= datetime.strptime(end_date, "%Y-%m-%d"))
    
    orders = query.all()
    
    # 汇总数据
    total_sales = sum(o.total_amount for o in orders)
    total_product_cost = sum(o.product_cost for o in orders)
    total_commission = sum(o.commission for o in orders)
    total_logistics = sum(o.logistics_fee for o in orders)
    total_ad_cost = sum(o.ad_cost for o in orders)
    total_profit = sum(o.profit for o in orders)
    
    # 平均利润率
    avg_profit_rate = sum(o.profit_rate for o in orders) / len(orders) if orders else 0
    
    # 成本构成
    total_cost = total_product_cost + total_commission + total_logistics + total_ad_cost
    cost_breakdown = {
        "产品成本": total_product_cost,
        "平台佣金": total_commission,
        "物流费": total_logistics,
        "广告费": total_ad_cost
    } if total_cost > 0 else {}
    
    # 按产品汇总
    product_query = db.query(OrderItem)
    if orders:
        order_ids = [o.id for o in orders]
        product_query = product_query.filter(OrderItem.order_id.in_(order_ids))
    
    product_items = product_query.all()
    
    # 按产品聚合
    product_profits = {}
    for item in product_items:
        if item.product_id not in product_profits:
            product = db.query(Product).filter(Product.id == item.product_id).first()
            product_profits[item.product_id] = {
                "product_id": item.product_id,
                "product": {"nm_id": product.nm_id, "name": product.name, "custom_name": product.custom_name} if product else None,
                "sales": 0,
                "product_cost": 0,
                "commission": 0,
                "logistics_fee": 0,
                "ad_cost": 0,
                "profit": 0,
                "profit_rate": 0,
                "order_count": 0
            }
        
        product_profits[item.product_id]["sales"] += item.total_price or 0
        product_profits[item.product_id]["product_cost"] += item.product_cost or 0
        product_profits[item.product_id]["order_count"] += 1
    
    # 计算利润
    for pid, data in product_profits.items():
        if data["sales"] > 0:
            data["profit"] = data["sales"] - data["product_cost"] - data["commission"] - data["logistics_fee"] - data["ad_cost"]
            data["profit_rate"] = data["profit"] / data["sales"]
    
    # 趋势数据
    trend_query = db.query(
        func.date(Order.order_date).label("date"),
        func.sum(Order.total_amount).label("sales"),
        func.sum(Order.profit).label("profit")
    )
    
    if shop_id:
        trend_query = trend_query.filter(Order.shop_id == shop_id)
    
    if start_date:
        trend_query = trend_query.filter(Order.order_date >= datetime.strptime(start_date, "%Y-%m-%d"))
    
    if end_date:
        trend_query = trend_query.filter(Order.order_date <= datetime.strptime(end_date, "%Y-%m-%d"))
    
    trend_results = trend_query.group_by(func.date(Order.order_date)).order_by("date").all()
    
    trend = [
        {"date": str(r.date), "sales": r.sales or 0, "profit": r.profit or 0}
        for r in trend_results
    ]
    
    return {
        "summary": {
            "totalSales": total_sales,
            "totalCost": total_cost,
            "totalProfit": total_profit,
            "avgProfitRate": avg_profit_rate,
            "totalOrders": len(orders)
        },
        "costBreakdown": cost_breakdown,
        "products": list(product_profits.values()),
        "trend": trend
    }


@router.get("/by-product/")
def finance_by_product(
    product_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """单个产品财务分析"""
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        return {"error": "产品不存在"}
    
    # 该产品的订单明细
    order_items = db.query(OrderItem).filter(OrderItem.product_id == product_id).all()
    
    total_sales = sum(i.total_price for i in order_items)
    total_cost = sum(i.product_cost for i in order_items)
    
    return {
        "product_id": product_id,
        "product": {
            "nm_id": product.nm_id,
            "name": product.name,
            "custom_name": product.custom_name
        },
        "total_sales": total_sales,
        "total_cost": total_cost,
        "total_profit": total_sales - total_cost,
        "profit_rate": (total_sales - total_cost) / total_sales if total_sales > 0 else 0,
        "order_count": len(order_items)
    }
