"""
产品管理路由
"""
from datetime import datetime
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from pydantic import BaseModel

from app.database import get_db
from app.models.models import Product, Shop, SyncLog, AdRecord, Order, OrderItem
from app.routers.auth import get_current_user, get_current_admin
from app.services.sync import SyncService
from app.services.wb_api import WBAPIClient

router = APIRouter(prefix="/products", tags=["产品管理"])


# ========== 请求/响应模型 ==========

class ProductCreate(BaseModel):
    nm_id: str
    sku: str
    name: str
    custom_name: Optional[str] = None
    owner: Optional[str] = None
    weight: Optional[float] = None
    length: Optional[float] = None
    width: Optional[float] = None
    height: Optional[float] = None


class ProductUpdate(BaseModel):
    custom_name: Optional[str] = None
    owner: Optional[str] = None
    weight: Optional[float] = None
    length: Optional[float] = None
    width: Optional[float] = None
    height: Optional[float] = None


class ProductResponse(BaseModel):
    id: int
    nm_id: str
    sku: str
    shop_id: int
    name: str
    custom_name: Optional[str] = None
    owner: Optional[str] = None
    weight: Optional[float] = None
    length: Optional[float] = None
    width: Optional[float] = None
    height: Optional[float] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True


# ========== 路由 ==========

@router.get("/", response_model=List[ProductResponse])
def list_products(
    shop_id: Optional[int] = None,
    owner: Optional[str] = None,
    search: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """获取产品列表"""
    query = db.query(Product)
    
    if shop_id:
        query = query.filter(Product.shop_id == shop_id)
    
    if owner:
        query = query.filter(Product.owner == owner)
    
    if search:
        query = query.filter(
            Product.name.contains(search) |
            Product.custom_name.contains(search) |
            Product.sku.contains(search)
        )
    
    products = query.offset(skip).limit(limit).all()
    return products


@router.get("/{product_id}/", response_model=ProductResponse)
def get_product(
    product_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """获取产品详情"""
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="产品不存在")
    return product


@router.put("/{product_id}/", response_model=ProductResponse)
def update_product(
    product_id: int,
    data: ProductUpdate,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """更新产品（自定义字段）"""
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="产品不存在")
    
    # 更新可编辑字段
    update_data = data.dict(exclude_unset=True)
    for key, value in update_data.items():
        setattr(product, key, value)
    
    db.commit()
    db.refresh(product)
    return product


@router.post("/{product_id}/assign-owner/")
def assign_owner(
    product_id: int,
    owner: str,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """分配负责人"""
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="产品不存在")
    
    product.owner = owner
    db.commit()
    
    return {"message": f"产品 {product.nm_id} 分配给 {owner}"}


@router.post("/sync/{shop_id}/")
def sync_products_from_wildberries(
    shop_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_admin)
):
    """从 WB 同步产品（只新增不覆盖）"""
    shop = db.query(Shop).filter(Shop.id == shop_id).first()
    if not shop:
        raise HTTPException(status_code=404, detail="店铺不存在")
    
    sync_service = SyncService(db, shop)
    result = sync_service.sync_products()
    
    if result["success"]:
        return {
            "success": True,
            "message": f"成功同步 {result['count']} 个产品"
        }
    else:
        raise HTTPException(
            status_code=500,
            detail=f"同步失败: {result.get('error')}"
        )


@router.get("/owners/list/")
def list_owners(
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """获取所有负责人列表"""
    owners = db.query(Product.owner).filter(Product.owner != None).distinct().all()
    return [o[0] for o in owners if o[0]]


@router.get("/{product_id}/ads/")
def get_product_ads(
    product_id: int,
    date_from: str = None,
    date_to: str = None,
    ad_type: str = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """获取产品广告数据 - 优先从本地数据库读取"""
    from datetime import datetime, timedelta
    
    # 获取产品信息
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="产品不存在")
    
    # 设置默认日期
    if not date_to:
        date_to = datetime.now().strftime("%Y-%m-%d")
    if not date_from:
        date_from = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")
    
    # ============ 从ad_records表获取product_analytics数据 ============
    from sqlalchemy import func, text, cast, String
    
    # 1. 获取产品销售漏斗数据（product_analytics类型）
    product_analytics_query = text("""
        SELECT 
            COALESCE(SUM(impressions), 0) as total_visitors,
            COALESCE(SUM(clicks), 0) as cart_count,
            COALESCE(SUM(orders), 0) as orders,
            COALESCE(SUM(sales), 0) as sales
        FROM ad_records
        WHERE product_id = :product_id
        AND ad_type = 'product_analytics'
        AND record_date >= :date_from
        AND record_date <= :date_to
    """)
    
    import logging
    logger = logging.getLogger(__name__)
    logger.info(f"DEBUG: 查询产品{product_id}销售数据, 日期范围: {date_from} 到 {date_to}")
    analytics_result = db.execute(product_analytics_query, {
        "product_id": product_id, 
        "date_from": date_from, 
        "date_to": date_to
    }).first()
    
    # 从product_analytics数据获取核心指标
    total_visitors = int(analytics_result.total_visitors) if analytics_result.total_visitors else 0
    cart_count = int(analytics_result.cart_count) if analytics_result.cart_count else 0
    orders = int(analytics_result.orders) if analytics_result.orders else 0
    sales = float(analytics_result.sales) if analytics_result.sales else 0
    logger.info(f"DEBUG: 查询结果 - 销售额: {sales}, 订单数: {orders}, 总访客: {total_visitors}")
    
    # 2. 获取广告数据 (advertising类型)
    ad_query = text("""
        SELECT 
            COALESCE(SUM(clicks), 0) as ad_visitors,
            COALESCE(SUM(cost), 0) as ad_spend,
            COALESCE(SUM(impressions), 0) as ad_impressions,
            0 as ad_cart_count
        FROM ad_records
        WHERE product_id = :product_id
        AND ad_type = 'advertising'
        AND record_date >= :date_from
        AND record_date <= :date_to
    """)
    
    ad_result = db.execute(ad_query, {
        "product_id": product_id, 
        "date_from": date_from, 
        "date_to": date_to
    }).first()
    
    ad_visitors = float(ad_result.ad_visitors) if ad_result.ad_visitors else 0
    ad_spend = float(ad_result.ad_spend) if ad_result.ad_spend else 0
    ad_impressions = int(ad_result.ad_impressions) if ad_result.ad_impressions else 0
    ad_cart_count = int(ad_result.ad_cart_count) if ad_result.ad_cart_count else 0
    
    # 3. 计算衍生指标
    ad_ctr = ad_visitors / ad_impressions if ad_impressions > 0 else 0
    ad_cart_rate = ad_cart_count / ad_visitors if ad_visitors > 0 else 0
    cpc = ad_spend / ad_visitors if ad_visitors > 0 else 0
    
    # 4. 汇总数据（用于返回）
    summary = {
        "sales": float(sales),  # 销售额（来自product_analytics）
        "orders": int(orders),  # 订单数（来自product_analytics）
        "total_visitors": int(total_visitors),  # 总访客（来自product_analytics）
        "ad_visitors": int(ad_visitors),  # 广告访客
        "ad_spend": float(ad_spend),  # 广告费
        "ad_ctr": float(ad_ctr),  # 广告点击率
        "ad_cart_rate": float(ad_cart_rate),  # 广告加购率
        "cpc": float(cpc),  # CPC
    }
    
    # 5. 获取日级数据用于图表
    daily_analytics = db.query(
        AdRecord.record_date,
        func.sum(AdRecord.impressions).label('impressions')
    ).filter(
        AdRecord.product_id == product_id,
        AdRecord.ad_type == "product_analytics",
        AdRecord.record_date >= date_from,
        AdRecord.record_date <= date_to
    ).group_by(AdRecord.record_date).all()
    
    daily_ads = db.query(
        AdRecord.record_date,
        func.sum(AdRecord.clicks).label('clicks'),
        func.sum(AdRecord.cost).label('cost'),
        func.sum(AdRecord.impressions).label('impressions')
    ).filter(
        AdRecord.product_id == product_id,
        AdRecord.ad_type == "advertising",
        AdRecord.record_date >= date_from,
        AdRecord.record_date <= date_to
    ).group_by(AdRecord.record_date).all()
    
    # 合并日级数据
    daily_agg = {}
    for record in daily_analytics:
        date_key = record.record_date.strftime("%Y-%m-%d") if isinstance(record.record_date, datetime) else str(record.record_date)
        daily_agg[date_key] = {
            "date": date_key,
            "total_visitors": record.impressions or 0,
            "ad_visitors": 0,
            "ad_impressions": 0,
            "ad_spend": 0
        }
    
    for record in daily_ads:
        date_key = record.record_date.strftime("%Y-%m-%d") if isinstance(record.record_date, datetime) else str(record.record_date)
        if date_key not in daily_agg:
            daily_agg[date_key] = {
                "date": date_key,
                "total_visitors": 0,
                "ad_visitors": 0,
                "ad_impressions": 0,
                "ad_spend": 0
            }
        daily_agg[date_key]["ad_visitors"] = record.clicks or 0
        daily_agg[date_key]["ad_impressions"] = record.impressions or 0
        daily_agg[date_key]["ad_spend"] = record.cost or 0
    
    # 获取广告活动列表
    adverts = []
    if 'advertising_records' in dir():
        adverts = [{"id": r.id, "name": f"广告 {r.id}", "status": 11, "type": r.ad_type or "cpm", "bid_type": "manual"} for r in advertising_records[:10]]
    
    # 按广告活动和日期汇总详细数据
    ad_daily_details = {}
    if 'advertising_records' in dir():
        for record in advertising_records:
            advert_id = getattr(record, 'advert_id', 0) or 0
            date_str = record.record_date.strftime("%Y-%m-%d") if isinstance(record.record_date, datetime) else str(record.record_date)[:10]
            key = (advert_id, date_str)
            if key not in ad_daily_details:
                ad_daily_details[key] = {"advert_id": advert_id, "date": date_str, "impressions": 0, "clicks": 0, "cost": 0, "orders": 0}
            ad_daily_details[key]["impressions"] += record.impressions or 0
            ad_daily_details[key]["clicks"] += record.clicks or 0
            ad_daily_details[key]["cost"] += record.cost or 0
            ad_daily_details[key]["orders"] += record.orders or 0
    
    ad_details = list(ad_daily_details.values())
    
    return {"summary": summary, "daily_data": list(daily_agg.values()), "adverts": adverts, "ad_details": ad_details, "source": "database"}
    
    # ============ 数据库无数据，尝试API ============
    from app.services.wb_api import WBAPIClient
    
    shop = db.query(Shop).filter(Shop.id == product.shop_id).first()
    if not shop or not shop.api_token:
        raise HTTPException(status_code=400, detail="店铺没有API Token")
    
    client = WBAPIClient(shop.api_token)
    adverts = client.get_adverts()
    
    product_ads = []
    product_ad_ids = []
    nm_id = str(product.nm_id)
    for ad in adverts:
        for nm in ad.get("nm_settings", []):
            if str(nm.get("nm_id")) == nm_id:
                ad_data = {
                    "id": ad.get("id"), 
                    "name": ad.get("settings", {}).get("name", ""), 
                    "status": ad.get("status"), 
                    "type": ad.get("type", ""),
                    "type_name": ad.get("type_name", ""),
                    "payment_type": ad.get("settings", {}).get("payment_type", ""), 
                    "bid_type": ad.get("bid_type")
                }
                if ad_data not in product_ads:
                    product_ads.append(ad_data)
                    product_ad_ids.append(ad.get("id"))
    
    daily_data = []
    summary = {"impressions": 0, "clicks": 0, "ctr": 0, "spend": 0, "sales": 0, "roas": 0, "acos": 0}
    
    if product_ad_ids:
        try:
            stats = client.get_ad_stats(ids=product_ad_ids, date_from=date_from, date_to=date_to)
            for stat in stats:
                for day in stat.get("days", []):
                    date = day.get("date", "")[:10]
                    summary["impressions"] += day.get("views", 0)
                    summary["clicks"] += day.get("clicks", 0)
                    summary["spend"] += day.get("sum", 0)
                    for app in day.get("apps", []):
                        for nm in app.get("nms", []):
                            if str(nm.get("nmId")) == nm_id:
                                daily_data.append({"date": date, "impressions": nm.get("views", 0), "clicks": nm.get("clicks", 0), "spend": nm.get("sum", 0), "orders": nm.get("orders", 0), "sales": nm.get("sum_price", 0)})
                                summary["sales"] += nm.get("sum_price", 0)
        except Exception as e:
            print(f"获取广告统计失败: {e}")
    
    if summary["impressions"] > 0:
        summary["ctr"] = summary["clicks"] / summary["impressions"]
    if summary["spend"] > 0:
        summary["roas"] = summary["sales"] / summary["spend"]
        summary["acos"] = (summary["spend"] / summary["sales"]) * 100 if summary["sales"] > 0 else 0
    
    return {"summary": summary, "daily_data": daily_data, "adverts": product_ads, "source": "api"}


@router.get("/{product_id}/traffic-source/")
def get_product_traffic_source(
    product_id: int,
    date_from: str = None,
    date_to: str = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """获取产品流量来源分析 - 广告访客 vs 自然访客"""
    from datetime import datetime, timedelta
    
    # 获取产品信息
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="产品不存在")
    
    # 设置默认日期
    if not date_to:
        date_to = datetime.now().strftime("%Y-%m-%d")
    if not date_from:
        date_from = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
    
    # 获取产品分析数据（总访客）
    analytics_query = db.query(AdRecord).filter(
        AdRecord.product_id == product_id,
        AdRecord.record_date >= date_from,
        AdRecord.record_date <= date_to,
        AdRecord.ad_type == "product_analytics"
    )
    analytics_records = analytics_query.all()
    
    total_visitors = sum(r.impressions or 0 for r in analytics_records)
    
    # 获取广告访客数据
    advertising_query = db.query(AdRecord).filter(
        AdRecord.product_id == product_id,
        AdRecord.record_date >= date_from,
        AdRecord.record_date <= date_to,
        AdRecord.ad_type == "advertising"
    )
    advertising_records = advertising_query.all()
    
    ad_visitors = sum(r.impressions or 0 for r in advertising_records)
    ad_clicks = sum(r.clicks or 0 for r in advertising_records)
    
    # 计算自然访客
    natural_visitors = max(0, total_visitors - ad_visitors)
    
    # 计算比例
    if total_visitors > 0:
        ad_ratio = round(ad_visitors / total_visitors * 100, 1)
        natural_ratio = round(natural_visitors / total_visitors * 100, 1)
    else:
        ad_ratio = 0
        natural_ratio = 0
    
    return {
        "product_id": product_id,
        "product_name": product.name,
        "date_from": date_from,
        "date_to": date_to,
        "total_visitors": total_visitors,
        "ad_visitors": ad_visitors,
        "ad_clicks": ad_clicks,
        "natural_visitors": natural_visitors,
        "other_visitors": 0,
        "ad_ratio": ad_ratio,
        "natural_ratio": natural_ratio,
        "other_ratio": 0
    }
