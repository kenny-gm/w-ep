"""
数据同步服务
支持：
1. 新店铺：自动同步90天历史数据（按天分批）
2. 已存在店铺：增量同步（只拉取新数据）
3. 数据去重：存在则更新，不存在则插入
"""
import json
import logging
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from typing import Optional, Dict, Any, List
from sqlalchemy.orm import Session
from sqlalchemy import and_
from app.models.models import (
    Shop, Product, Order, OrderItem, InventorySnapshot,
    AdRecord, SyncLog, InventoryRecord
)
from app.services.wb_api import WBAPIClient

logger = logging.getLogger("sync")


class SyncService:
    """数据同步服务"""
    
    # 新店铺同步历史天数
    HISTORY_DAYS = 30
    
    # 每批请求间隔（秒），避免限流
    BATCH_INTERVAL = 1.0
    
    def __init__(self, db: Session, shop: Shop):
        self.db = db
        self.shop = shop
        self.client = WBAPIClient(shop.api_token)
        self.shop_id = shop.id
    
    def is_new_shop(self) -> bool:
        """判断是否为新店铺（从未同步过）"""
        return self.shop.last_sync_at is None
    
    def _create_sync_log(self, sync_type: str) -> SyncLog:
        """创建同步日志"""
        sync_log = SyncLog(
            shop_id=self.shop_id,
            sync_type=sync_type,
            status="running"
        )
        self.db.add(sync_log)
        self.db.commit()
        return sync_log
    
    def _finish_sync_log(self, sync_log: SyncLog, success: bool, count: int = 0, message: str = ""):
        """完成同步日志"""
        sync_log.status = "success" if success else "failed"
        sync_log.records_count = count
        sync_log.message = message
        sync_log.finished_at = datetime.now(ZoneInfo("Asia/Shanghai"))
        self.db.commit()
    
    # ==================== 商品同步 ====================
    
    def sync_products(self, limit: int = 1000, overwrite: bool = False) -> dict:
        """
        同步商品
        
        Args:
            limit: 每批获取数量
            overwrite: 是否覆盖已存在的商品
        
        Returns:
            {"success": bool, "count": int, "updated": int}
        """
        sync_log = self._create_sync_log("products")
        
        try:
            count = 0
            updated = 0
            
            logger.info(f"开始同步产品，shop_id={self.shop_id}")
            
            # 先尝试Content API
            cards = self.client.get_products(limit=limit, offset=0, locale="ru")
            logger.info(f"Content API返回: {len(cards)}个产品")
            
            # 如果Content API返回空，使用Statistics API
            if not cards:
                logger.info("Content API返回空，尝试Statistics API")
                cards = self.client.get_products_from_statistics()
                logger.info(f"Statistics API返回: {len(cards)}个产品")
            
            if not cards:
                logger.info("没有产品数据")
                self._finish_sync_log(sync_log, True, 0, "没有产品数据")
                return {"success": True, "count": 0, "updated": 0}
            
            # 打印第一个产品的结构用于调试
            logger.info(f"第一个产品数据示例: {json.dumps(cards[0], ensure_ascii=False)[:300]}")
            
            for card in cards:
                # 根据API来源解析字段
                nm_id = str(card.get("nmID", card.get("nmId", "")))
                if not nm_id:
                    logger.warning(f"产品缺少nmID: {card}")
                    continue
                
                # vendorCode 或 supplierArticle 是 SKU
                vendor_code = card.get("vendorCode", card.get("supplierArticle", ""))
                
                # 获取产品名称
                name = f"产品 {nm_id}"
                characteristics = card.get("characterstics", [])
                for char in characteristics:
                    if char.get("name") == "Наименование" or char.get("id") == 0:
                        name = char.get("value", "")
                        break
                
                # 如果没有从characteristics获取到名称，使用默认名称
                if name == f"产品 {nm_id}":
                    # Statistics API返回的数据没有characteristics，使用SKU作为名称
                    if vendor_code:
                        name = vendor_code
                
                logger.info(f"处理产品: nmID={nm_id}, vendorCode={vendor_code}, name={name[:30]}")
                
                # 查找已存在商品
                existing = self.db.query(Product).filter(
                    Product.nm_id == nm_id,
                    Product.shop_id == self.shop_id
                ).first()
                
                if existing:
                    if overwrite:
                        # 更新已存在商品
                        existing.name = name
                        existing.sku = vendor_code
                        updated += 1
                        logger.info(f"更新产品: {nm_id}")
                    continue
                else:
                    # 创建新商品
                    product = Product(
                        nm_id=nm_id,
                        sku=vendor_code,
                        shop_id=self.shop_id,
                        name=name,
                        custom_name=name,
                    )
                    self.db.add(product)
                    count += 1
                    logger.info(f"新增产品: nmID={nm_id}, name={name[:30]}")
            
            # 更新同步时间
            self.shop.last_sync_at = datetime.now(ZoneInfo("Asia/Shanghai"))
            self.db.commit()
            
            self._finish_sync_log(sync_log, True, count, f"新增 {count} 个，更新 {updated} 个")
            
            return {"success": True, "count": count, "updated": updated}
            
        except Exception as e:
            logger.error(f"同步商品失败: {e}")
            self._finish_sync_log(sync_log, False, 0, str(e))
            return {"success": False, "error": str(e)}
    
    # ==================== 订单同步 ====================
    
    def sync_orders(self, days: Optional[int] = 30, incremental: bool = True) -> dict:
        """
        同步订单 - 使用Analytics API获取销售数据
        
        Args:
            days: 同步天数（默认90天）
            incremental: 是否增量同步
        
        Returns:
            {"success": bool, "count": int, "updated": int}
        """
        sync_log = self._create_sync_log("orders")
        
        try:
            # 获取店铺的nmId列表
            products = self.db.query(Product).filter(
                Product.shop_id == self.shop_id,
                Product.nm_id.isnot(None)
            ).all()
            
            nm_ids = [int(p.nm_id) for p in products if p.nm_id]
            
            if not nm_ids:
                logger.warning(f"店铺{self.shop_id}没有产品，跳过订单同步")
                self._finish_sync_log(sync_log, True, 0, "没有产品")
                return {"success": True, "count": 0, "updated": 0}
            
            logger.info(f"店铺{self.shop_id}产品数: {len(nm_ids)}")
            
            # 确定同步日期范围（Analytics API最多支持7天）
            if days is None or days > 7:
                days = 7
            date_to = datetime.now(ZoneInfo("Asia/Shanghai")).strftime("%Y-%m-%d")
            date_from = (datetime.now(ZoneInfo("Asia/Shanghai")) - timedelta(days=days)).strftime("%Y-%m-%d")
            
            # 获取Analytics API销售数据
            logger.info(f"使用Analytics API获取销售数据: {date_from} - {date_to}")
            analytics_result = self.client.get_product_stats(date_from, date_to, nm_ids)
            
            if not analytics_result or not analytics_result.get("daily"):
                logger.warning("Analytics API返回空数据")
                self._finish_sync_log(sync_log, True, 0, "无数据")
                return {"success": True, "count": 0, "updated": 0}
            
            analytics_data = analytics_result.get("daily", {})
            product_data = analytics_result.get("by_product", {})
            
            print(f"DEBUG: Analytics API返回: {len(analytics_data)}天数据, {len(product_data)}条产品数据")
            logger.info(f"Analytics API返回: {len(analytics_data)}天数据, {len(product_data)}条产品数据")
            
            # 获取店铺的汇率配置
            exchange_rate = self.shop.exchange_rate or 12.5
            logger.info(f"店铺{self.shop_id}汇率: {exchange_rate}")
            
            # 清除旧订单，重新同步
            if not incremental:
                self.db.query(Order).filter(Order.shop_id == self.shop_id).delete()
                logger.info(f"已清除店铺{self.shop_id}的旧订单")
            
            count = 0
            updated = 0
            
            # 遍历每日数据，创建订单记录
            for date_str, day_data in analytics_data.items():
                try:
                    order_date = datetime.strptime(date_str, "%Y-%m-%d")
                except:
                    continue
                
                # 获取金额
                # Analytics API返回的orderSum根据店铺currency设置：
                # - 如果店铺货币是RUB，返回的是卢布
                # - 如果店铺货币是CNY，返回的是人民币
                # 存储原始金额，不转换
                original_amount = day_data.get("order_sum", 0)
                
                # 直接存储原始金额
                total_amount = original_amount
                
                order_count = day_data.get("order_count", 0)
                
                if order_count == 0:
                    continue
                
                # 创建一条汇总订单记录
                # 使用日期作为唯一标识
                order_id = f"analytics_{self.shop_id}_{date_str}"
                
                existing = self.db.query(Order).filter(
                    Order.order_id == order_id,
                    Order.shop_id == self.shop_id
                ).first()
                
                if existing:
                    # 更新
                    existing.total_amount = total_amount
                    existing.updated_at = datetime.now(ZoneInfo("Asia/Shanghai"))
                    updated += 1
                else:
                    # 创建
                    order = Order(
                        order_id=order_id,
                        shop_id=self.shop_id,
                        status="new",
                        total_amount=total_amount,
                        commission=0,
                        logistics_fee=0,
                        order_date=order_date
                    )
                    self.db.add(order)
                    count += 1
            
            self.db.commit()
            
            # 记录访客和加购数据（店铺级别）
            self._sync_analytics_stats(analytics_data)
            
            # 记录产品级别数据（用于按负责人汇总）
            if product_data:
                self._sync_product_analytics(product_data, nm_ids)
            
            sync_log.status = "success"
            sync_log.records_count = count
            sync_log.finished_at = datetime.now(ZoneInfo("Asia/Shanghai"))
            self.db.commit()
            
            logger.info(f"订单同步完成: 新增{count}个，更新{updated}个")
            return {"success": True, "count": count, "updated": updated}
            
        except Exception as e:
            logger.error(f"同步订单失败: {e}")
            self._finish_sync_log(sync_log, False, 0, str(e))
            return {"success": False, "error": str(e)}
    
    def _sync_analytics_stats(self, analytics_data: Dict[str, Any]):
        """记录访客和加购数据"""
        try:
            # 遍历每日数据，创建或更新每日统计记录
            for date_str, day_data in analytics_data.items():
                try:
                    record_date = date_str  # 直接使用 YYYY-MM-DD 格式
                except:
                    continue
                
                visitors = day_data.get("visitors", 0)
                cart_count = day_data.get("cart_count", 0)
                order_count = day_data.get("order_count", 0)
                
                # 使用product_id=0表示店铺级别汇总
                existing = self.db.query(AdRecord).filter(
                    AdRecord.shop_id == self.shop_id,
                    AdRecord.product_id == 0,
                    AdRecord.record_date == record_date,
                    AdRecord.ad_type == "analytics"
                ).first()
                
                if existing:
                    existing.impressions = visitors
                    existing.clicks = cart_count
                    existing.orders = order_count
                else:
                    # 创建新记录
                    ad_record = AdRecord(
                        shop_id=self.shop_id,
                        product_id=0,
                        ad_type="analytics",
                        impressions=visitors,
                        clicks=cart_count,
                        orders=order_count,
                        record_date=record_date
                    )
                    self.db.add(ad_record)
            
            self.db.commit()
            logger.info("Analytics统计数据同步完成")
        except Exception as e:
            logger.error(f"同步Analytics统计失败: {e}")
    
    def _sync_product_analytics(self, product_data: Dict[str, Any], nm_ids: List[int]):
        """记录产品级别的Analytics数据（用于按负责人汇总）"""
        try:
            # 建立nm_id到product.id的映射
            products = self.db.query(Product).filter(
                Product.shop_id == self.shop_id,
                Product.nm_id.in_([str(nm) for nm in nm_ids])
            ).all()
            nm_to_product = {p.nm_id: p for p in products}
            
            # 遍历产品+日期数据
            for (nm_id, date_str), data in product_data.items():
                try:
                    record_date = date_str  # 直接使用 YYYY-MM-DD 格式
                except:
                    continue
                
                # 查找产品
                product = nm_to_product.get(str(nm_id))
                if not product:
                    continue
                
                # 存储到ad_records表（使用ad_type="product_analytics"）
                existing = self.db.query(AdRecord).filter(
                    AdRecord.shop_id == self.shop_id,
                    AdRecord.product_id == product.id,
                    AdRecord.record_date == record_date,
                    AdRecord.ad_type == "product_analytics"
                ).first()
                
                if existing:
                    existing.impressions = data.get("visitors", 0)
                    existing.clicks = data.get("cart_count", 0)
                    existing.orders = data.get("order_count", 0)
                    existing.sales = data.get("order_sum", 0)
                else:
                    ad_record = AdRecord(
                        shop_id=self.shop_id,
                        product_id=product.id,
                        ad_type="product_analytics",
                        impressions=data.get("visitors", 0),
                        clicks=data.get("cart_count", 0),
                        orders=data.get("order_count", 0),
                        sales=data.get("order_sum", 0),
                        record_date=record_date
                    )
                    self.db.add(ad_record)
            
            self.db.commit()
            logger.info(f"产品级Analytics数据同步完成: {len(product_data)}条")
        except Exception as e:
            logger.error(f"同步产品Analytics失败: {e}")
    
    def _upsert_order(self, order_data: dict) -> str:
        """
        插入或更新订单 - 支持两种格式：
        1. Marketplace API格式：orderUid, id, nmId, price, salePrice, createdAt
        2. Statistics API格式：gNumber, srid, nmId, totalPrice, date
        
        Returns:
            "created" | "updated" | "skipped"
        """
        # 尝试多种可能的唯一标识符字段
        # Marketplace API格式
        order_uid = str(order_data.get("orderUid", ""))
        order_id = str(order_data.get("id", ""))
        
        # Statistics API格式
        g_number = str(order_data.get("gNumber", ""))
        srid = str(order_data.get("srid", "")).split(".")[0] if order_data.get("srid") else ""
        
        # 选择一个唯一标识符
        if order_uid:
            unique_id = order_uid
        elif order_id:
            unique_id = f"wb_{order_id}"
        elif g_number:
            unique_id = g_number
        elif srid:
            unique_id = f"srid_{srid}"
        else:
            logger.warning(f"订单缺少唯一标识符: {order_data}")
            return "skipped"
        
        # 解析订单日期
        order_date = None
        # Statistics API格式
        if order_data.get("date"):
            try:
                order_date = datetime.fromisoformat(order_data["date"].replace("Z", "+00:00")).replace(tzinfo=None)
            except:
                pass
        # Marketplace API格式
        if not order_date and order_data.get("createdAt"):
            try:
                order_date = datetime.fromisoformat(order_data["createdAt"].replace("Z", "+00:00")).replace(tzinfo=None)
            except:
                pass
        
        if not order_date:
            order_date = datetime.now(ZoneInfo("Asia/Shanghai"))
        
        # 获取金额 - 使用priceWithDisc（买家实际支付金额，最接近WB后台）
        total_amount = 0
        # Statistics API: priceWithDisc 是买家实际支付金额
        if order_data.get("priceWithDisc"):
            total_amount = float(order_data.get("priceWithDisc", 0))
        # 如果没有，尝试其他字段
        elif order_data.get("totalPrice"):
            total_amount = float(order_data.get("totalPrice", 0))
        elif order_data.get("finishedPrice"):
            total_amount = float(order_data.get("finishedPrice", 0))
        elif order_data.get("salePrice"):
            total_amount = float(order_data.get("salePrice", 0))
        
        # 查找已存在订单
        existing = self.db.query(Order).filter(
            Order.order_id == unique_id,
            Order.shop_id == self.shop_id
        ).first()
        
        if existing:
            # 更新已存在订单
            existing.status = "new"
            existing.total_amount = total_amount
            existing.updated_at = datetime.now(ZoneInfo("Asia/Shanghai"))
            if order_date:
                existing.order_date = order_date
            return "updated"
        else:
            # 创建新订单 - 使用计算好的total_amount
            order = Order(
                order_id=unique_id,
                shop_id=self.shop_id,
                status="new",
                total_amount=total_amount,
                commission=0,
                logistics_fee=0,
                order_date=order_date or datetime.now(ZoneInfo("Asia/Shanghai"))
            )
            self.db.add(order)
            self.db.flush()  # 获取 order.id
            
            # 创建订单明细
            nm_id = str(order_data.get("nmId", ""))
            sku = order_data.get("article", "") or order_data.get("skus", [""])[0] if order_data.get("skus") else ""
            
            # 查找产品
            product = self.db.query(Product).filter(
                Product.nm_id == nm_id,
                Product.shop_id == self.shop_id
            ).first()
            
            item_obj = OrderItem(
                order_id=order.id,
                product_id=product.id if product else None,
                nm_id=nm_id,
                sku=sku,
                quantity=1,
                price=order_data.get("price", 0) or 0,
                total_price=order_data.get("salePrice", 0) or 0
            )
            self.db.add(item_obj)
            
            return "created"
    
    # ==================== 库存同步 ====================
    
    def sync_inventory(self) -> dict:
        """
        同步库存快照
        
        Returns:
            {"success": bool, "count": int}
        """
        sync_log = self._create_sync_log("inventory")
        
        try:
            warehouses = self.client.get_warehouses()
            
            count = 0
            for wh in warehouses:
                wh_id = str(wh.get("id", ""))
                wh_name = wh.get("name", "")
                
                stocks = self.client.get_inventory(wh_id)
                
                for stock in stocks:
                    nm_id = str(stock.get("nmId", ""))
                    if not nm_id:
                        continue
                    
                    product = self.db.query(Product).filter(
                        Product.nm_id == nm_id,
                        Product.shop_id == self.shop_id
                    ).first()
                    
                    if not product:
                        continue
                    
                    # 创建库存快照（每次同步都是新快照）
                    snapshot = InventorySnapshot(
                        product_id=product.id,
                        warehouse_id=wh_id,
                        warehouse_name=wh_name,
                        quantity=stock.get("amount", 0) or 0
                    )
                    self.db.add(snapshot)
                    count += 1
            
            self.shop.last_sync_at = datetime.now(ZoneInfo("Asia/Shanghai"))
            self.db.commit()
            
            self._finish_sync_log(sync_log, True, count)
            
            return {"success": True, "count": count}
            
        except Exception as e:
            logger.error(f"同步库存失败: {e}")
            self._finish_sync_log(sync_log, False, 0, str(e))
            return {"success": False, "error": str(e)}
    
    # ==================== 广告同步 ====================
    
    def sync_ads(self, days: Optional[int] = 30) -> dict:
        """
        同步广告数据 - 使用fullstats API
        
        Args:
            days: 同步天数（None表示自动判断）
        
        Returns:
            {"success": bool, "count": int, "updated": int}
        """
        sync_log = self._create_sync_log("ads")
        
        try:
            date_to = datetime.now(ZoneInfo("Asia/Shanghai")).strftime("%Y-%m-%d")
            
            if days:
                date_from = (datetime.now(ZoneInfo("Asia/Shanghai")) - timedelta(days=days)).strftime("%Y-%m-%d")
            elif self.shop.last_sync_at:
                date_from = (self.shop.last_sync_at - timedelta(days=1)).strftime("%Y-%m-%d")
            else:
                date_from = (datetime.now(ZoneInfo("Asia/Shanghai")) - timedelta(days=self.HISTORY_DAYS)).strftime("%Y-%m-%d")
            
            stats = self.client.get_ad_stats(date_from=date_from, date_to=date_to)
            
            count = 0
            updated = 0
            
            for stat in stats:
                # fullstats返回的数据结构是嵌套的，需要遍历days数组
                advert_id = stat.get("advertId")
                days_data = stat.get("days", [])
                
                for day_data in days_data:
                    # 获取日期
                    date_str = day_data.get("date", "")
                    if date_str:
                        try:
                            record_date = datetime.fromisoformat(date_str.replace("Z", "+00:00")).replace(tzinfo=None)
                        except:
                            record_date = datetime.now(ZoneInfo("Asia/Shanghai"))
                    else:
                        record_date = datetime.now(ZoneInfo("Asia/Shanghai"))
                    
                    # 汇总这一天的数据
                    day_sum = day_data.get("sum", 0) or 0
                    day_views = day_data.get("views", 0) or 0
                    day_clicks = day_data.get("clicks", 0) or 0
                    day_orders = day_data.get("orders", 0) or 0
                    
                    # 遍历产品
                    apps = day_data.get("apps", [])
                    for app in apps:
                        nms = app.get("nms", [])
                        for nm_data in nms:
                            nm_id = str(nm_data.get("nmId", ""))
                            if not nm_id:
                                continue
                            
                            # 查找产品
                            product = self.db.query(Product).filter(
                                Product.nm_id == nm_id,
                                Product.shop_id == self.shop_id
                            ).first()
                            
                            if not product:
                                continue
                            
                            # 获取该产品的费用
                            nm_sum = nm_data.get("sum", 0) or 0
                            nm_views = nm_data.get("views", 0) or 0
                            nm_clicks = nm_data.get("clicks", 0) or 0
                            nm_orders = nm_data.get("orders", 0) or 0
                            
                            # 创建或更新广告记录
                            existing = self.db.query(AdRecord).filter(
                                AdRecord.shop_id == self.shop_id,
                                AdRecord.product_id == product.id,
                                AdRecord.record_date == record_date,
                                AdRecord.ad_type == "advertising"
                            ).first()
                            
                            if existing:
                                existing.impressions = nm_views
                                existing.clicks = nm_clicks
                                existing.cost = nm_sum
                                existing.orders = nm_orders
                                updated += 1
                            else:
                                ad_record = AdRecord(
                                    product_id=product.id,
                                    shop_id=self.shop_id,
                                    ad_type="advertising",
                                    impressions=nm_views,
                                    clicks=nm_clicks,
                                    cost=nm_sum,
                                    orders=nm_orders,
                                    record_date=record_date
                                )
                                self.db.add(ad_record)
                                count += 1
            
            self.shop.last_sync_at = datetime.now(ZoneInfo("Asia/Shanghai"))
            self.db.commit()
            
            self._finish_sync_log(sync_log, True, count, f"新增 {count} 条广告记录")
            
            return {"success": True, "count": count, "updated": updated}
            
        except Exception as e:
            logger.error(f"同步广告失败: {e}")
            self._finish_sync_log(sync_log, False, 0, str(e))
            return {"success": False, "error": str(e)}
    
    # ==================== 全量同步 ====================
    
    def sync_all(self, history: bool = False) -> dict:
        """
        全量同步
        
        Args:
            history: 是否同步历史数据（新店铺用）
        
        Returns:
            各模块同步结果
        """
        results = {}
        
        # 1. 先同步商品（必须先执行，订单依赖商品）
        logger.info("开始同步商品...")
        results["products"] = self.sync_products(overwrite=True)
        
        if not results["products"]["success"]:
            return results
        
        # 2. 同步订单
        logger.info("开始同步订单...")
        results["orders"] = self.sync_orders()
        
        # 3. 同步库存
        logger.info("开始同步库存...")
        results["inventory"] = self.sync_inventory()
        
        # 4. 同步广告
        logger.info("开始同步广告...")
        if history or self.is_new_shop():
            results["ads"] = self.sync_ads(days=self.HISTORY_DAYS)
        else:
            results["ads"] = self.sync_ads()
        
        # 5. 同步产品销售漏斗数据（依赖产品数据）
        logger.info("开始同步产品销售漏斗数据...")
        if history or self.is_new_shop():
            results["product_sales"] = self.sync_product_sales(days=self.HISTORY_DAYS)
        else:
            results["product_sales"] = self.sync_product_sales()
        
        logger.info("全量同步完成!")
        return results
    
    def sync_product_sales(self, days: Optional[int] = 30) -> dict:
        """
        同步产品销售漏斗数据
        从WB API获取产品销售数据，保存到ad_records表（ad_type='product_analytics'）
        
        Args:
            days: 同步天数，默认30天
            
        Returns:
            {"success": bool, "count": int, "updated": int}
        """
        sync_log = self._create_sync_log("product_sales")
        
        try:
            # 获取店铺所有产品
            products = self.db.query(Product).filter(
                Product.shop_id == self.shop_id,
                Product.nm_id != "0"  # 排除店铺汇总
            ).all()
            
            if not products:
                self._finish_sync_log(sync_log, True, 0, "无产品需要同步")
                return {"success": True, "count": 0, "updated": 0}
            
            # 设置日期范围
            date_to = datetime.now(ZoneInfo("Asia/Shanghai")).strftime("%Y-%m-%d")
            date_from = (datetime.now(ZoneInfo("Asia/Shanghai")) - timedelta(days=days)).strftime("%Y-%m-%d")
            
            # 获取产品nm_id列表
            nm_ids = [int(p.nm_id) for p in products if p.nm_id and p.nm_id.isdigit()]
            
            if not nm_ids:
                self._finish_sync_log(sync_log, True, 0, "无有效产品ID")
                return {"success": True, "count": 0, "updated": 0}
            
            logger.info(f"开始同步产品销售数据: {len(nm_ids)}个产品, {date_from} - {date_to}")
            
            # 调用WB API获取产品销售漏斗数据
            product_sales_data = self.client.get_product_sales_funnel(nm_ids, date_from, date_to)
            
            if not product_sales_data:
                self._finish_sync_log(sync_log, True, 0, "API返回空数据")
                return {"success": True, "count": 0, "updated": 0}
            
            # 建立nm_id到product.id的映射
            nm_to_product = {p.nm_id: p.id for p in products}
            
            count = 0
            updated = 0
            
            # 遍历产品数据
            for nm_id_str, daily_data in product_sales_data.items():
                product_id = nm_to_product.get(nm_id_str)
                if not product_id:
                    continue
                
                # 遍历每日数据
                for date_str, stats in daily_data.items():
                    try:
                        record_date = date_str  # 直接使用 YYYY-MM-DD 格式
                    except:
                        continue
                    
                    # 查找或创建记录
                    existing = self.db.query(AdRecord).filter(
                        AdRecord.shop_id == self.shop_id,
                        AdRecord.product_id == product_id,
                        AdRecord.record_date == record_date,
                        AdRecord.ad_type == "product_analytics"
                    ).first()
                    
                    if existing:
                        # 更新现有记录
                        existing.impressions = stats.get("visitors", 0)
                        existing.clicks = stats.get("cart_count", 0)  # 保存为clicks字段
                        # existing.cart_count = stats.get("cart_count", 0)  # 同时保存到cart_count字段
                        existing.orders = stats.get("order_count", 0)
                        existing.sales = stats.get("order_sum", 0)
                        updated += 1
                    else:
                        # 创建新记录
                        ad_record = AdRecord(
                            shop_id=self.shop_id,
                            product_id=product_id,
                            ad_type="product_analytics",
                            impressions=stats.get("visitors", 0),
                            clicks=stats.get("cart_count", 0),  # 保存为clicks字段
                            # cart_count=stats.get("cart_count", 0),  # 同时保存到cart_count字段
                            orders=stats.get("order_count", 0),
                            sales=stats.get("order_sum", 0),
                            record_date=record_date
                        )
                        self.db.add(ad_record)
                        count += 1
            
            self.db.commit()
            
            total = count + updated
            logger.info(f"产品销售数据同步完成: 新增{count}条, 更新{updated}条, 总计{total}条")
            
            self._finish_sync_log(sync_log, True, total, f"同步{total}条产品销售数据")
            return {"success": True, "count": count, "updated": updated, "total": total}
            
        except Exception as e:
            logger.error(f"同步产品销售数据失败: {e}")
            self._finish_sync_log(sync_log, False, 0, str(e))
            return {"success": False, "error": str(e)}


# ==================== 订单利润计算 ====================

def calculate_order_profit(db: Session, order: Order) -> Order:
    """计算订单利润"""
    items = db.query(OrderItem).filter(OrderItem.order_id == order.id).all()
    
    total_product_cost = 0
    
    for item in items:
        if item.product_id:
            # FIFO 计算产品成本
            records = db.query(InventoryRecord).filter(
                InventoryRecord.product_id == item.product_id,
                InventoryRecord.remaining_quantity > 0
            ).order_by(InventoryRecord.inbound_at).all()
            
            remaining_qty = item.quantity
            item_cost = 0
            
            for record in records:
                if remaining_qty <= 0:
                    break
                
                take_qty = min(remaining_qty, record.remaining_quantity)
                item_cost += take_qty * record.product_cost
                record.remaining_quantity -= take_qty
                remaining_qty -= take_qty
            
            item.product_cost = item_cost
            total_product_cost += item_cost
    
    # 计算利润
    order.product_cost = total_product_cost
    order.profit = (
        order.total_amount 
        - order.commission 
        - order.logistics_fee 
        - order.product_cost 
        - order.ad_cost 
        - order.other_cost
    )
    
    # 计算利润率
    if order.total_amount > 0:
        order.profit_rate = order.profit / order.total_amount
    
    return order
