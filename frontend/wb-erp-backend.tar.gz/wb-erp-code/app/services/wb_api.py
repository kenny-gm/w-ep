"""
WB API 客户端
支持多个API分类的统一调用接口
支持从系统设置读取限流配置
"""

import httpx
import time
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from dataclasses import dataclass


# 从数据库加载限流配置
def _load_rate_limits() -> Dict[str, 'RateLimiter']:
    """从系统设置加载限流配置"""
    default_limits = {
        "content": {"limit": 100, "interval": 0.6, "burst": 10},
        "marketplace": {"limit": 300, "interval": 0.2, "burst": 20},
        "analytics": {"limit": 3, "interval": 20.0, "burst": 1},
        "statistics": {"limit": 3, "interval": 20.0, "burst": 1},
        "promotion": {"limit": 3, "interval": 20.0, "burst": 1},
        "finance": {"limit": 60, "interval": 1.0, "burst": 5},
    }
    
    # 尝试从数据库加载
    try:
        from app.database import SessionLocal
        from app.models.models import SystemSetting
        
        db = SessionLocal()
        setting_map = {}
        for s in db.query(SystemSetting).filter(SystemSetting.key.like("rate_limit_%")).all():
            setting_map[s.key] = s.value
        db.close()
        
        # 更新限流配置
        if "rate_limit_content_per_minute" in setting_map:
            default_limits["content"]["limit"] = int(setting_map["rate_limit_content_per_minute"])
        if "rate_limit_stats_per_minute" in setting_map:
            default_limits["statistics"]["limit"] = int(setting_map["rate_limit_stats_per_minute"])
        if "rate_limit_analytics_per_minute" in setting_map:
            default_limits["analytics"]["limit"] = int(setting_map["rate_limit_analytics_per_minute"])
        if "rate_limit_ad_per_minute" in setting_map:
            default_limits["promotion"]["limit"] = int(setting_map["rate_limit_ad_per_minute"])
            
        print(f"限流配置已从数据库加载: {default_limits}")
    except Exception as e:
        print(f"无法加载限流配置，使用默认: {e}")
    
    return default_limits


@dataclass
class RateLimiter:
    """API 限流控制器"""
    limit: int  # 时间窗口内最大请求数
    interval: float  # 时间窗口（秒）
    burst: int  # 允许的突发请求数
    window_seconds: int = 60  # 滑动窗口大小
    
    def __init__(self, **kwargs):
        for key, value in kwargs.items():
            setattr(self, key, value)
        self.requests = []
    
    def wait_if_needed(self):
        """如果需要，等待到有可用配额"""
        now = time.time()
        # 清理过期请求
        self.requests = [t for t in self.requests if now - t < self.window_seconds]
        
        # 检查是否需要等待
        if len(self.requests) >= self.limit:
            # 计算需要等待的时间
            wait_time = self.window_seconds - (now - self.requests[0])
            if wait_time > 0:
                time.sleep(wait_time)
        
        # 记录本次请求
        self.requests.append(now)
    
    def add_cost(self, cost: int = 1):
        """增加请求消耗（用于错误处理）"""
        for _ in range(cost):
            self.requests.append(time.time())


class WBAPIClient:
    """Wildberries API 客户端"""
    
    # API域名映射
    API_DOMAINS = {
        "common": "https://common-api.wildberries.ru",
        "content": "https://content-api.wildberries.ru",
        "marketplace": "https://marketplace-api.wildberries.ru",
        "analytics": "https://seller-analytics-api.wildberries.ru",
        "statistics": "https://statistics-api.wildberries.ru",
        "promotion": "https://advert-api.wildberries.ru",
        "finance": "https://finance-api.wildberries.ru",
    }
    
    # 限流配置（在__init__中从数据库加载）
    RATE_LIMITS = {}
    
    # 错误码对应的请求消耗倍数
    ERROR_COST_MULTIPLIER = {
        409: 5,   # 状态更新错误
        429: 5,   # 限流错误
    }
    
    def __init__(self, api_token: str):
        self.api_token = api_token
        self.headers = {
            "Authorization": api_token,
            "Content-Type": "application/json"
        }
        
        # 从数据库加载限流配置
        self._init_rate_limits()
    
    def _init_rate_limits(self):
        """从系统设置初始化限流配置"""
        default_limits = {
            "content": {"limit": 100, "interval": 0.6, "burst": 10},
            "marketplace": {"limit": 300, "interval": 0.2, "burst": 20},
            "analytics": {"limit": 3, "interval": 20.0, "burst": 1},
            "statistics": {"limit": 3, "interval": 20.0, "burst": 1},
            "promotion": {"limit": 3, "interval": 20.0, "burst": 1},
            "finance": {"limit": 60, "interval": 1.0, "burst": 5},
        }
        
        try:
            from app.database import SessionLocal
            from app.models.models import SystemSetting
            
            db = SessionLocal()
            setting_map = {}
            for s in db.query(SystemSetting).filter(SystemSetting.key.like("rate_limit_%")).all():
                setting_map[s.key] = s.value
            db.close()
            
            # 更新限流配置
            if "rate_limit_content_per_minute" in setting_map:
                default_limits["content"]["limit"] = int(setting_map["rate_limit_content_per_minute"])
            if "rate_limit_stats_per_minute" in setting_map:
                default_limits["statistics"]["limit"] = int(setting_map["rate_limit_stats_per_minute"])
            if "rate_limit_analytics_per_minute" in setting_map:
                default_limits["analytics"]["limit"] = int(setting_map["rate_limit_analytics_per_minute"])
            if "rate_limit_ad_per_minute" in setting_map:
                default_limits["promotion"]["limit"] = int(setting_map["rate_limit_ad_per_minute"])
                
            print(f"限流配置已加载: {default_limits}")
        except Exception as e:
            print(f"无法加载限流配置，使用默认: {e}")
        
        # 创建限流器
        WBAPIClient.RATE_LIMITS = {
            "content": RateLimiter(**default_limits["content"], window_seconds=60),
            "marketplace": RateLimiter(**default_limits["marketplace"], window_seconds=60),
            "analytics": RateLimiter(**default_limits["analytics"], window_seconds=60),
            "statistics": RateLimiter(**default_limits["statistics"], window_seconds=60),
            "promotion": RateLimiter(**default_limits["promotion"], window_seconds=60),
            "finance": RateLimiter(**default_limits["finance"], window_seconds=60),
        }
    
    def _get_limiter(self, category: str) -> RateLimiter:
        """获取指定分类的限流器"""
        if category not in self.RATE_LIMITS:
            return self.RATE_LIMITS["marketplace"]
        return self.RATE_LIMITS[category]
    
    def _request(
        self,
        method: str,
        category: str,
        endpoint: str,
        params: Optional[Dict] = None,
        json_data: Optional[Dict] = None,
        retry: int = 3
    ) -> Dict[str, Any]:
        """发送 API 请求"""
        url = f"{self.API_DOMAINS.get(category, '')}{endpoint}"
        limiter = self._get_limiter(category)
        
        last_error = None
        
        for attempt in range(retry):
            try:
                limiter.wait_if_needed()
                
                with httpx.Client(timeout=30.0) as client:
                    if method == "GET":
                        response = client.get(url, headers=self.headers, params=params)
                    elif method == "POST":
                        response = client.post(url, headers=self.headers, params=params, json=json_data)
                    elif method == "PUT":
                        response = client.put(url, headers=self.headers, params=params, json=json_data)
                    elif method == "DELETE":
                        response = client.delete(url, headers=self.headers, params=params)
                    else:
                        raise ValueError(f"Unsupported method: {method}")
                    
                    if response.status_code == 200:
                        return response.json()
                    elif response.status_code == 204:
                        return {}
                    elif response.status_code == 429:
                        print(f"Rate limited (429), waiting... attempt {attempt + 1}/{retry}")
                        limiter.add_cost(5)
                        time.sleep(60)
                        continue
                    elif response.status_code == 409:
                        limiter.add_cost(5)
                        if attempt < retry - 1:
                            time.sleep(20)
                            continue
                        raise Exception(f"API 请求失败 [{response.status_code}]: {response.text}")
                    elif response.status_code == 401:
                        raise Exception(f"API 认证失败 (401): Token 无效或已过期")
                    elif response.status_code == 403:
                        raise Exception(f"API 权限不足 (403): {response.text[:200]}")
                    elif response.status_code == 404:
                        raise Exception(f"API 端点不存在 [404]: {url}")
                    else:
                        raise Exception(f"API 请求失败 [{response.status_code}]: {response.text[:200]}")
                        
            except httpx.TimeoutException:
                last_error = Exception("API 请求超时")
                if attempt < retry - 1:
                    time.sleep(2)
                    continue
            except httpx.NetworkError:
                last_error = Exception("网络错误")
                if attempt < retry - 1:
                    time.sleep(5)
                    continue
            except Exception as e:
                if "认证失败" in str(e) or "权限不足" in str(e):
                    raise
                last_error = e
                if attempt < retry - 1:
                    time.sleep(2)
                    continue
        
        raise last_error or Exception("API 请求失败")
    
    # ========== 通用接口 ==========
    def ping(self) -> bool:
        """测试 API 连接"""
        try:
            self._request("GET", "common", "/api/v1/seller-info")
            return True
        except Exception:
            return False
    
    # ========== 商品相关 ==========
    def get_products(self, limit: int = 100, offset: int = 0, locale: str = "zh") -> List[Dict[str, Any]]:
        """获取商品列表 - 使用Content API"""
        try:
            response = self._request(
                "POST", "content", "/content/v2/get/cards/list",
                json_data={"limit": limit, "offset": offset, "locale": locale}
            )
            return response.get("cards", [])
        except Exception as e:
            print(f"get_products错误: {e}")
            return []
    
    def get_products_from_statistics(self) -> List[Dict[str, Any]]:
        """
        从Statistics API获取商品列表（当Content API不可用时使用）
        通过库存数据获取唯一的商品列表
        """
        try:
            # 获取库存数据（包含所有有库存的商品）
            response = self._request(
                "GET", "statistics", "/api/v1/supplier/stocks",
                params={"dateFrom": "2020-01-01"}
            )
            
            if not isinstance(response, list):
                return []
            
            # 提取唯一商品
            unique_products = {}
            for item in response:
                nm_id = item.get("nmId")
                if nm_id and nm_id not in unique_products:
                    unique_products[nm_id] = {
                        "nmID": nm_id,
                        "vendorCode": item.get("supplierArticle", ""),
                        "barcode": item.get("barcode", ""),
                        "techSize": item.get("techSize", ""),
                        "quantity": item.get("quantity", 0),
                    }
            
            return list(unique_products.values())
        except Exception as e:
            print(f"get_products_from_statistics错误: {e}")
            return []
    
    def get_products_all(self, locale: str = "zh") -> List[Dict[str, Any]]:
        """获取所有商品"""
        all_products = []
        offset = 0
        limit = 100
        
        while True:
            products = self.get_products(limit=limit, offset=offset, locale=locale)
            all_products.extend(products)
            if len(products) < limit:
                break
            offset += limit
        
        return all_products
    
    # ========== 订单相关 ==========
    def get_new_orders(self) -> List[Dict[str, Any]]:
        """获取新订单"""
        response = self._request("GET", "marketplace", "/api/v3/orders/new")
        return response.get("orders", [])
    
    def get_orders(self, limit: int = 1000, offset: int = 0) -> List[Dict[str, Any]]:
        """获取订单列表"""
        response = self._request(
            "GET", "marketplace", "/api/v3/orders",
            params={"limit": limit, "offset": offset}
        )
        return response.get("orders", [])
    
    def get_orders_from_statistics(self, date_from: str = None) -> List[Dict[str, Any]]:
        """
        从Statistics API获取订单数据（当Marketplace API不可用时使用）
        """
        try:
            if not date_from:
                # 默认获取90天数据
                date_from = (datetime.now() - timedelta(days=90)).strftime("%Y-%m-%d")
            
            response = self._request(
                "GET", "statistics", "/api/v1/supplier/orders",
                params={"dateFrom": date_from}
            )
            
            if isinstance(response, list):
                return response
            return []
        except Exception as e:
            print(f"get_orders_from_statistics错误: {e}")
            return []
    
    # ========== 库存相关 ==========
    def get_warehouses(self) -> List[Dict[str, Any]]:
        """获取仓库列表"""
        response = self._request("GET", "marketplace", "/api/v3/warehouses")
        return response
    
    def get_inventory(self, warehouse_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """获取库存数据"""
        params = {}
        if warehouse_id:
            params["warehouseId"] = warehouse_id
        
        response = self._request(
            "GET", "marketplace", "/api/v3/stocks",
            params=params
        )
        return response.get("stocks", [])
    
    # ========== 广告相关 ==========
    def get_adverts(self) -> List[Dict[str, Any]]:
        """获取广告列表"""
        response = self._request("GET", "promotion", "/api/advert/v2/adverts")
        adverts = response.get("adverts", []) if isinstance(response, dict) else (response if isinstance(response, list) else [])
        
        # 添加广告类型分类
        for ad in adverts:
            payment_type = ad.get("settings", {}).get("payment_type", "")
            placements = ad.get("settings", {}).get("placements", {})
            
            if payment_type == "cpm" and placements.get("recommendations"):
                ad["type"] = "cpm_recommend"
                ad["type_name"] = "CPM推荐"
            elif payment_type == "cpm" and placements.get("search"):
                ad["type"] = "cpm_search"
                ad["type_name"] = "CPM搜索"
            elif payment_type == "cpc" and placements.get("search"):
                ad["type"] = "cpc_search"
                ad["type_name"] = "CPC搜索"
            else:
                ad["type"] = "other"
                ad["type_name"] = "其他"
        
        return adverts
    
    def get_ad_stats(self, ids: Optional[List[int]] = None, date_from: Optional[str] = None, date_to: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        获取广告统计 - 使用 v3/fullstats API
        请求的最大周期为 31 天
        每次请求最多50个广告ID
        """
        try:
            if not ids:
                adverts = self.get_adverts()
                ids = [adv.get("id") for adv in adverts if adv.get("id")]
            
            if not ids:
                return []
            
            # 设置默认日期
            if not date_from:
                from datetime import datetime, timedelta
                date_from = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
            if not date_to:
                date_to = datetime.now().strftime("%Y-%m-%d")
            
            # 分批请求，每批最多50个ID
            all_stats = []
            batch_size = 50
            
            for i in range(0, len(ids), batch_size):
                batch_ids = ids[i:i + batch_size]
                
                params = {
                    "ids": ",".join(map(str, batch_ids)),
                    "beginDate": date_from,
                    "endDate": date_to
                }
                
                # 使用 v3/fullstats API
                response = self._request("GET", "promotion", "/adv/v3/fullstats", params=params)
                
                if isinstance(response, list):
                    all_stats.extend(response)
                
                # 每批之间稍作等待，避免限流
                if i + batch_size < len(ids):
                    import time
                    time.sleep(20)
            
            return all_stats
        except Exception as e:
            print(f"Ad stats API error: {e}")
            return []
    
    # ========== 分析相关 ==========
    def get_sales(self, date_from: str, date_to: str) -> List[Dict[str, Any]]:
        """获取销售数据"""
        try:
            response = self._request(
                "GET", "statistics", "/api/v1/supplier/sales",
                params={"dateFrom": date_from, "dateTo": date_to}
            )
            return response if isinstance(response, list) else []
        except Exception as e:
            print(f"Sales API error: {e}")
            return []
    
    def get_sales_history(self, date_from: str, date_to: str) -> List[Dict[str, Any]]:
        """获取销售历史"""
        try:
            response = self._request(
                "POST", "analytics", "/api/analytics/v3/sales-funnel/products/history",
                json_data={"period": {"begin": date_from, "end": date_to}}
            )
            return response.get("data", {}).get("products", []) if response else []
        except Exception as e:
            print(f"Sales history API error: {e}")
            return []

    def get_financial_report(self, date_from: str, date_to: str) -> List[Dict[str, Any]]:
        """
        获取财务报告（每周销售报告）
        接口：POST /api/v5/supplier/reportDetailByPeriod
        """
        try:
            json_data = {
                "dateFrom": date_from,
                "dateTo": date_to,
                "limit": 1000,
                "offset": 0
            }
            
            response = self._request(
                "POST", "statistics", "/api/v5/supplier/reportDetailByPeriod",
                json_data=json_data
            )
            
            if isinstance(response, dict):
                return response.get("data", [])
            return response if isinstance(response, list) else []
        except Exception as e:
            print(f"Financial report API error: {e}")
            return []

    def get_ad_normquery_stats(self, date_from: str = None, date_to: str = None) -> List[Dict[str, Any]]:
        """
        获取广告统计（新版API）
        接口：POST /adv/v1/normquery/stats
        """
        try:
            json_data = {
                "period": {
                    "begin": date_from,
                    "end": date_to
                }
            }
            
            response = self._request(
                "POST", "promotion", "/adv/v1/normquery/stats",
                json_data=json_data
            )
            
            if isinstance(response, list):
                return response
            return response.get("data", []) if isinstance(response, dict) else []
        except Exception as e:
            print(f"Ad normquery stats API error: {e}")
            return []

    
    def get_sales_funnel(self, date_from: str, date_to: str) -> Dict[str, Any]:
        """获取销售漏斗"""
        response = self._request(
            "POST", "analytics", "/api/v1/sales-funnel",
            json_data={"dateFrom": date_from, "dateTo": date_to}
        )
        return response or {}
    
    def get_product_stats(self, date_from: str, date_to: str, nm_ids: Optional[List[int]] = None) -> List[Dict[str, Any]]:
        """获取产品统计"""
        try:
            json_data = {
                "period": {"begin": date_from, "end": date_to},
                "brandNames": [],
                "objectIDs": [],
                "nmIDs": nm_ids or []
            }
            
            response = self._request(
                "POST", "analytics", "/api/v2/nm-report",
                json_data=json_data
            )
            return response.get("data", {}).get("cards", []) if response else []
        except Exception as e:
            print(f"Product stats API error: {e}")
            return []
    
    def get_product_sales_funnel(self, nm_ids: List[int], date_from: str, date_to: str) -> Dict[str, Any]:
        """
        获取产品销售漏斗数据
        接口：POST /api/analytics/v3/sales-funnel/products/history
        返回：{nm_id: {date: {visitors, cart_count, order_count, order_sum}}}
        """
        try:
            if not nm_ids:
                return {}
            
            json_data = {
                "nmIds": nm_ids,
                "selectedPeriod": {
                    "start": date_from,
                    "end": date_to
                }
            }
            
            response = self._request(
                "POST", "analytics", "/api/analytics/v3/sales-funnel/products/history",
                json_data=json_data
            )
            
            if not response:
                return {}
            
            # 按产品组织数据
            product_data = {}
            for product in response:
                nm_id = product.get("product", {}).get("nmId")
                if not nm_id:
                    continue
                
                product_data[nm_id] = {}
                for day in product.get("history", []):
                    date = day.get("date")
                    product_data[nm_id][date] = {
                        "visitors": day.get("openCount", 0),
                        "cart_count": day.get("cartCount", 0),
                        "order_count": day.get("orderCount", 0),
                        "order_sum": day.get("orderSum", 0)
                    }
            
            return product_data
        except Exception as e:
            print(f"Product sales funnel API error: {e}")
            return {}
